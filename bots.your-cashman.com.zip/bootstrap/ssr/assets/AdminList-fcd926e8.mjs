import { resolveDirective, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrLooseEqual, ssrGetDirectiveProps, ssrGetDynamicModelProps, ssrInterpolate, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { P as Pagination } from "./Pagination-05b9527c.mjs";
import { mapGetters } from "vuex";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const __default__ = {
  data() {
    return {
      loading: false,
      admins: [],
      admins_paginate_object: null,
      message: null,
      type: 0,
      phone: null
    };
  },
  computed: {
    ...mapGetters([
      "getAdmins",
      "getAdminsPaginateObject"
    ]),
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  mounted() {
    this.loadAdmins();
  },
  methods: {
    nextAdminPage(index) {
      this.loadAdmins(index);
    },
    sendRequest(botUser, index) {
      this.loading = true;
      this.$store.dispatch("requestAdmin", {
        dataObject: {
          bot_id: botUser.bot_id,
          admin_telegram_chat_id: botUser.telegram_chat_id,
          user_telegram_chat_id: this.tgUser.id,
          message: this.message,
          type: this.type,
          phone: this.phone
        }
      }).then((resp) => {
        this.loading = false;
        this.tg.close();
      }).catch(() => {
        this.loading = false;
      });
    },
    loadAdmins(page = 0) {
      this.loading = true;
      this.$store.dispatch("loadAdmins", {
        dataObject: {
          bot_domain: this.bot.bot_domain
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.admins = this.getAdmins;
        this.admins_paginate_object = this.getAdminsPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "AdminList",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_mask = resolveDirective("mask");
      let _temp0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container pt-3 pb-3" }, _attrs))}><div class="row"><div class="col-12 mb-3"><div class="card border-success"><div class="card-body"><p> Вы можете выбрать администратора из списка активных администраторов и прислать ему запрос `);
      if (_ctx.type == 0) {
        _push(`<span>на начисление <strong>CashBack</strong>.</span>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.type == 1) {
        _push(`<span>на бронирование столика. Обязательно укажите свой <b>номер телефона</b> для обратной связи.</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(` К запросу вы можете прикрепить текстовое сообщение, которое также получит выбранный администратор. </p></div></div></div><div class="col-12">`);
      if (_ctx.admins.length > 0) {
        _push(`<div><div class="btn-group mb-3" role="group" aria-label="Basic radio toggle button group"><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.type, "0")) ? " checked" : ""} class="btn-check" value="0" name="btnradio" id="btnradio1" autocomplete="off" checked><label class="btn btn-outline-primary" for="btnradio1">Начислить CashBack</label><input type="radio" class="btn-check"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.type, "1")) ? " checked" : ""} value="1" name="btnradio" id="btnradio2" autocomplete="off"><label class="btn btn-outline-primary" for="btnradio2">Забронировать столик</label></div>`);
        if (_ctx.type == 1) {
          _push(`<div class="input-group mb-3"><span class="input-group-text" id="booking-phone">Телефон</span><input${ssrRenderAttrs((_temp0 = mergeProps({
            type: "text",
            class: "form-control",
            value: _ctx.phone,
            placeholder: "+7(000)000-00-00",
            "aria-label": "vipForm-phone",
            "aria-describedby": "booking-phone"
          }, ssrGetDirectiveProps(_ctx, _directive_mask, "+7(###)###-##-##")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, _ctx.phone))))}></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<textarea type="text" placeholder="Сообщение администратору" class="form-control w-100 mb-3">${ssrInterpolate(_ctx.message)}</textarea></div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.admins.length > 0) {
        _push(`<div class="list-group"><!--[-->`);
        ssrRenderList(_ctx.admins, (item, index) => {
          _push(`<a href="#" class="list-group-item list-group-item-action"><div class="d-flex w-100 justify-content-between"><h5 class="mb-1">${ssrInterpolate(item.user.fio_from_telegram || item.user.name || "Не указано")}</h5><small class="text-muted">${ssrInterpolate(_ctx.$filters.timeAgo(item.updated_at))}</small></div><p class="mb-1">+${ssrInterpolate(item.user.phone || "Номер телефона не указан")}</p><small class="text-muted"><span class="badge text-bg-primary">Администратор</span></small></a>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<div class="alert alert-warning" role="alert"> К сожалению активных администраторов на данный момент нет, как только они будут в сети вы сможете запросить у них начисление бонусных баллов! </div>`);
      }
      _push(`</div>`);
      if (_ctx.admins.length > 0) {
        _push(`<div class="col-12">`);
        if (_ctx.admins_paginate_object) {
          _push(ssrRenderComponent(Pagination, {
            class: "mt-2",
            onPagination_page: _ctx.nextAdminPage,
            pagination: _ctx.admins_paginate_object
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/AdminList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
