import { useSSRContext, resolveDirective, mergeProps, resolveComponent } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrGetDirectiveProps, ssrGetDynamicModelProps, ssrIncludeBooleanAttr, ssrRenderStyle, ssrRenderComponent, ssrLooseContain, ssrRenderClass } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import { P as Pagination } from "./Pagination-05b9527c.mjs";
import { mapGetters } from "vuex";
import { Vue3JsonEditor } from "vue3-json-editor";
const Company_vue_vue_type_style_index_0_lang = "";
const _sfc_main$6 = {
  data() {
    return {
      load: false,
      photo: null,
      companyForm: {
        title: null,
        slug: null,
        description: null,
        address: null,
        phones: [""],
        links: [""],
        email: null,
        schedule: [],
        manager: null
      }
    };
  },
  methods: {
    getPhoto() {
      return { imageUrl: URL.createObjectURL(this.photo) };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      this.photo = files[0];
    },
    schedulePlaceholder() {
      if (this.companyForm.schedule.length > 0) {
        this.companyForm.schedule = [];
      } else {
        this.companyForm.schedule = [
          "Понедельник - с 8:00 до 20:00",
          "Вторник - с 8:00 до 20:00",
          "Среда - с 8:00 до 20:00",
          "Четверг - с 8:00 до 20:00",
          "Пятница - с 8:00 до 20:00",
          "Суббота - с 8:00 до 20:00",
          "Воскресенье - выходной"
        ];
      }
    },
    addItem(name) {
      this.companyForm[name].push("");
    },
    removeItem(name, index) {
      this.companyForm[name].splice(index, 1);
    },
    submitForm() {
      let data = new FormData();
      Object.keys(this.companyForm).forEach((key) => {
        const item = this.companyForm[key] || "";
        if (typeof item === "object")
          data.append(key, JSON.stringify(item));
        else
          data.append(key, item);
      });
      data.append("company_logo", this.photo);
      this.$store.dispatch("createCompany", {
        companyForm: data
      }).then((response) => {
        this.$emit("callback", response.data);
        this.$notify("Компания успешно создана");
      }).catch((err) => {
      });
    }
  }
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _directive_mask = resolveDirective("mask");
  const _directive_lazy = resolveDirective("lazy");
  let _temp0;
  _push(`<form${ssrRenderAttrs(_attrs)}><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="company-title">Название компании</label><input type="text" class="form-control" placeholder="Название" aria-label="Название"${ssrRenderAttr("value", $data.companyForm.title)} maxlength="255" aria-describedby="company-title" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-slug">Название компании латиницей (домен компании)</label><input type="text" class="form-control" placeholder="Мнемоническое имя" aria-label="Мнемоническое имя"${ssrRenderAttr("value", $data.companyForm.slug)} maxlength="255" aria-describedby="company-slug" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-description">Описание компании</label><textarea type="text" class="form-control" placeholder="Описание компании" aria-label="Описание компании" maxlength="255" aria-describedby="company-description" required>${ssrInterpolate($data.companyForm.description)}</textarea></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-address">Основной адрес компании</label><input type="text" class="form-control" placeholder="Адрес" aria-label="Адрес" maxlength="255"${ssrRenderAttr("value", $data.companyForm.address)} aria-describedby="company-address"></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-email">Основная почта компании</label><input type="email" class="form-control" placeholder="Почтовый адрес" aria-label="Почтовый адрес" maxlength="255"${ssrRenderAttr("value", $data.companyForm.email)} aria-describedby="company-email" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-manager">Менеджер компании</label><input type="text" class="form-control" placeholder="Имя менеджера" aria-label="Имя менеджера"${ssrRenderAttr("value", $data.companyForm.manager)} maxlength="255" aria-describedby="company-manager"></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Телефонные номера</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Телефонный номер</h6></div></div><!--[-->`);
  ssrRenderList($data.companyForm.phones, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input${ssrRenderAttrs((_temp0 = mergeProps({
      type: "text",
      class: "form-control",
      placeholder: "+7(000)000-00-00",
      "aria-label": "Номер телефона",
      maxlength: "255",
      value: $data.companyForm.phones[index],
      "aria-describedby": "company-phone-" + index
    }, ssrGetDirectiveProps(_ctx, _directive_mask, "+7(###)###-##-##")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, $data.companyForm.phones[index]))))}></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще номер </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Ссылки на соц. сети</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><!--[-->`);
  ssrRenderList($data.companyForm.links, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка на соц.сеть" aria-label="Ссылка на соц.сеть" maxlength="255"${ssrRenderAttr("value", $data.companyForm.links[index])}${ssrRenderAttr("aria-describedby", "company-link-" + index)}></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще ссылку </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>График работы</h6></div><div class="card-body"><div class="row"><div class="col-12 d-flex justify-content-between align-items-center"><h6>День недели </h6><a class="btn btn-link">Заполнить\\очистить</a></div></div><!--[-->`);
  ssrRenderList($data.companyForm.schedule, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input type="text" class="form-control" placeholder="День недели и время работы" aria-label="День недели и время работы" maxlength="255"${ssrRenderAttr("value", $data.companyForm.schedule[index])}${ssrRenderAttr("aria-describedby", "company-schedule-" + index)} required></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button"${ssrIncludeBooleanAttr($data.companyForm.schedule.length === 7) ? " disabled" : ""} class="btn btn-outline-success w-100">Добавить еще время работы </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Логотип компании</h6></div><div class="card-body d-flex justify-content-start"><label for="photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"> + <input type="file" id="photos" accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.photo) {
    _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto().imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div></div><div class="row"><div class="col-12"><button type="submit" class="btn btn-outline-success w-100 p-3">Создать компанию </button></div></div></form>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Company.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const Company = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$3]]);
const __default__$1 = {
  data() {
    return {
      loading: true,
      companies: [],
      search: null,
      companies_paginate_object: null
    };
  },
  computed: {
    ...mapGetters(["getCompanies", "getCompaniesPaginateObject"])
  },
  mounted() {
    this.loadCompanies();
  },
  methods: {
    selectCompany(company) {
      this.$emit("callback", company);
      this.$notify("Вы выбрали компанию из спика! Все остальные действия будут производится для этой компании.");
    },
    nextCompanies(index) {
      this.loadCompanies(index);
    },
    loadCompanies(page = 0) {
      this.loading = true;
      this.$store.dispatch("loadCompanies", {
        dataObject: {
          search: this.search
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.companies = this.getCompanies;
        this.companies_paginate_object = this.getCompaniesPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main$5 = /* @__PURE__ */ Object.assign(__default__$1, {
  __name: "CompanyList",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="row"><div class="input-group mb-3"><input type="search" class="form-control" placeholder="Поиск компании" aria-label="Поиск компании"${ssrRenderAttr("value", _ctx.search)} aria-describedby="button-addon2"><button class="btn btn-outline-secondary" type="button" id="button-addon2">Найти</button></div></div>`);
      if (_ctx.companies.length > 0) {
        _push(`<div class="row"><div class="col-12 mb-3"><ul class="list-group w-100"><!--[-->`);
        ssrRenderList(_ctx.companies, (company, index) => {
          _push(`<li class="list-group-item">${ssrInterpolate(company.title || "Не указано")} (${ssrInterpolate(company.slug || "Не указано")})</li>`);
        });
        _push(`<!--]--></ul></div><div class="col-12">`);
        if (_ctx.companies_paginate_object) {
          _push(ssrRenderComponent(Pagination, {
            onPagination_page: _ctx.nextCompanies,
            pagination: _ctx.companies_paginate_object
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/CompanyList.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  props: ["companyId"],
  data() {
    return {
      locations: [],
      locationForm: {
        lat: null,
        lon: null,
        address: null,
        description: null,
        location_channel: null,
        can_booking: false,
        photos: [],
        company_id: null
      }
    };
  },
  methods: {
    getPhoto(imgObject) {
      return { imageUrl: URL.createObjectURL(imgObject) };
    },
    removePhoto(index) {
      this.locationForm.photos.splice(index, 1);
    },
    removeItem(index) {
      this.locations.splice(index, 1);
    },
    submitLocations() {
      this.locations.forEach((location) => {
        let data = new FormData();
        Object.keys(location).forEach((key) => {
          const item = location[key] || "";
          if (typeof item === "object")
            data.append(key, JSON.stringify(item));
          else
            data.append(key, item);
        });
        for (let i = 0; i < location.photos.length; i++)
          data.append("images[]", location.photos[i]);
        data.delete("photos");
        this.$store.dispatch("createLocation", {
          locationForm: data
        }).then((response) => {
          this.$emit("callback", response.data);
          this.$notify("Локация успешно созадана и сохранена");
        }).catch((err) => {
        });
      });
    },
    addLocation() {
      this.locationForm.company_id = this.companyId;
      this.locations.push(this.locationForm);
      this.$notify("Локация успешно добавлена в список. Не забудьте сохранить");
      this.locationForm = {
        lat: null,
        lon: null,
        address: null,
        description: null,
        location_channel: null,
        can_booking: false,
        photos: []
      };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      for (let i = 0; i < files.length; i++)
        this.locationForm.photos.push(files[i]);
    }
  }
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _directive_mask = resolveDirective("mask");
  const _directive_lazy = resolveDirective("lazy");
  let _temp0, _temp1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))}><div class="card-body"><form><h6>Локации к компании #${ssrInterpolate($props.companyId || "Не установлен")}</h6><div class="row"><div class="col-12"><div class="form-check"><input class="form-check-input"${ssrIncludeBooleanAttr(Array.isArray($data.locationForm.can_booking) ? ssrLooseContain($data.locationForm.can_booking, "false") : $data.locationForm.can_booking) ? " checked" : ""} type="checkbox" value="false" id="flexCheckDefault"><label class="form-check-label" for="flexCheckDefault"> Можно бронировать столик </label></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="location-address">Адрес заведения</label><input type="text" class="form-control" placeholder="Адрес" aria-label="Адрес" maxlength="255"${ssrRenderAttr("value", $data.locationForm.address)} aria-describedby="location-address" required></div></div></div><div class="row"><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="location-lat">Широта</label><input${ssrRenderAttrs((_temp0 = mergeProps({
    type: "text",
    class: "form-control",
    placeholder: "##.######",
    "aria-label": "Широта",
    maxlength: "255",
    value: $data.locationForm.lat,
    "aria-describedby": "location-lat",
    required: ""
  }, ssrGetDirectiveProps(_ctx, _directive_mask, "##.######")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, $data.locationForm.lat))))}></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="location-lon">Долгота</label><input${ssrRenderAttrs((_temp1 = mergeProps({
    type: "text",
    class: "form-control",
    placeholder: "##.######",
    "aria-label": "Долгота",
    maxlength: "255",
    value: $data.locationForm.lon,
    "aria-describedby": "location-lon",
    required: ""
  }, ssrGetDirectiveProps(_ctx, _directive_mask, "##.######")), mergeProps(_temp1, ssrGetDynamicModelProps(_temp1, $data.locationForm.lon))))}></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="location-description">Описание компании</label><textarea type="text" class="form-control" placeholder="Описание локации" aria-label="Описание локации" maxlength="255" aria-describedby="location-description" required>${ssrInterpolate($data.locationForm.description)}</textarea></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="location-channel">Телеграм канал заведения</label><input type="text" class="form-control" placeholder="Номер телеграм канала" aria-label="Номер телеграм канала" maxlength="255"${ssrRenderAttr("value", $data.locationForm.location_channel)} aria-describedby="location-channel" required></div></div></div><div class="row"><div class="col-12 mb-3"><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="location-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="location-photos" multiple accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.locationForm.photos.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.locationForm.photos, (img, index) => {
      _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(img).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div><div class="row"><div class="col-12"><button class="btn btn-outline-success w-100" type="submit">Добавить локацию </button></div></div></form><div class="row">`);
  if ($data.locations.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.locations, (location, index) => {
      _push(`<div class="col-12 mt-3"><div class="card"><div class="card-header d-flex justify-content-between"><h6>Адрес локации <strong>${ssrInterpolate(location.address || "Не указано")}</strong> (ш:${ssrInterpolate(location.lat)},д:${ssrInterpolate(location.lon)}) `);
      if (location.can_booking) {
        _push(`<span class="badge bg-success">Можно забронировать столик</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</h6><a class="cursor-pointer">Удалить</a></div><div class="card-body"><p>Канал заведения <strong>${ssrInterpolate(location.location_channel)}</strong></p><p>${ssrInterpolate(location.description)}</p><div class="w-100 d-flex">`);
      if (location.photos.length > 0) {
        _push(`<!--[-->`);
        ssrRenderList(location.photos, (img, index2) => {
          _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(img).imageUrl))}></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="row mt-3"><div class="col-12"><button${ssrIncludeBooleanAttr($data.locations.length === 0) ? " disabled" : ""} class="btn btn-outline-primary p-3 w-100">Сохранить локации для заведения</button></div></div></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Location.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Location = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$3 = {
  props: ["companyId"],
  components: {
    Vue3JsonEditor
  },
  setup() {
  },
  data() {
    return {
      step: 0,
      templates: [],
      selectMenuIndex: null,
      botForm: {
        bot_domain: null,
        bot_token: null,
        bot_token_dev: null,
        order_channel: null,
        main_channel: null,
        balance: null,
        tax_per_day: null,
        image: null,
        description: null,
        info_link: null,
        social_links: [],
        maintenance_message: null,
        level_1: 10,
        level_2: 0,
        level_3: 0,
        photos: [],
        selected_bot_template_id: null,
        slugs: [],
        keyboards: []
      },
      editedButton: {
        keyboardIndex: null,
        rowIndex: null,
        colIndex: null,
        button: null
      }
    };
  },
  watch: {
    "botForm.selected_bot_template_id": function(oVal, nVal) {
      if (this.botForm.selected_bot_template_id != null) {
        this.loadMenusByBotTemplate(this.botForm.selected_bot_template_id);
        this.loadSlugsByBotTemplate(this.botForm.selected_bot_template_id);
      }
    }
  },
  mounted() {
    this.loadBotTemplates();
  },
  methods: {
    duplicateSlug(index) {
      const slug = JSON.stringify(this.botForm.slugs[index]);
      this.botForm.slugs.splice(index, 0, JSON.parse(slug));
    },
    removeSlug(index) {
      this.botForm.slugs.splice(index, 1);
    },
    editBtn(keyboardIndex, rowIndex, colIndex) {
      this.editedButton.button = this.botForm.keyboards[keyboardIndex].menu[rowIndex][colIndex];
      this.editedButton.colIndex = colIndex;
      this.editedButton.rowIndex = rowIndex;
      this.editedButton.keyboardIndex = keyboardIndex;
      console.log(this.editedButton);
    },
    onJsonChange(value) {
      this.botForm.keyboards[this.selectMenuIndex].menu = value;
    },
    loadMenusByBotTemplate(botId) {
      this.$store.dispatch("loadKeyboards", {
        botId
      }).then((resp) => {
        this.botForm.keyboards = resp.data;
      });
    },
    loadSlugsByBotTemplate(botId) {
      this.$store.dispatch("loadSlugs", {
        botId
      }).then((resp) => {
        this.botForm.slugs = resp.data;
      });
    },
    loadBotTemplates() {
      this.$store.dispatch("loadTemplates").then((resp) => {
        this.templates = resp.data;
      });
    },
    getPhoto(img) {
      return { imageUrl: URL.createObjectURL(img) };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      for (let i = 0; i < files.length; i++)
        this.botForm.photos.push(files[i]);
    },
    addItem(name) {
      this.botForm[name].push("");
    },
    addSocialLinks() {
      this.botForm.social_links.push({
        title: null,
        url: null
      });
    },
    removeItem(name, index) {
      this.botForm[name].splice(index, 1);
    },
    removePhoto(index) {
      this.botForm.photos.splice(index, 1);
    },
    addBot() {
      let data = new FormData();
      Object.keys(this.botForm).forEach((key) => {
        const item = this.botForm[key] || "";
        if (typeof item === "object")
          data.append(key, JSON.stringify(item));
        else
          data.append(key, item);
      });
      data.append("company_id", this.companyId);
      for (let i = 0; i < this.botForm.photos.length; i++)
        data.append("images[]", this.botForm.photos[i]);
      data.delete("photos");
      this.$store.dispatch("createBot", {
        botForm: data
      }).then((response) => {
        this.$emit("callback", response.data);
      }).catch((err) => {
      });
      this.botForm = {
        bot_domain: null,
        bot_token: null,
        bot_token_dev: null,
        order_channel: null,
        main_channel: null,
        balance: null,
        tax_per_day: null,
        image: null,
        description: null,
        info_link: null,
        social_links: [],
        maintenance_message: null,
        level_1: 10,
        level_2: 0,
        level_3: 0,
        photos: [],
        selected_bot_template_id: null,
        slugs: [],
        keyboards: []
      };
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Vue3JsonEditor = resolveComponent("Vue3JsonEditor");
  const _directive_lazy = resolveDirective("lazy");
  _push(`<!--[--><div class="row"><div class="col-12"><h6>Создаем бот к компании #${ssrInterpolate($props.companyId || "Не установлен")}</h6></div></div><div class="row mb-3 mt-3"><div class="col-12"><div class="btn-group w-100" role="group" aria-label="Basic outlined example"><button type="button" class="${ssrRenderClass([{ "btn-primary text-white": $data.step === 0 }, "btn btn-outline-primary"])}">Информация о боте </button><button type="button"${ssrIncludeBooleanAttr($data.botForm.selected_bot_template_id === null) ? " disabled" : ""} class="${ssrRenderClass([{ "btn-primary text-white": $data.step === 1 }, "btn btn-outline-primary"])}">Меню бота </button><button type="button"${ssrIncludeBooleanAttr($data.botForm.selected_bot_template_id === null) ? " disabled" : ""} class="${ssrRenderClass([{ "btn-primary text-white": $data.step === 2 }, "btn btn-outline-primary"])}">Команды бота </button></div></div></div><form>`);
  if ($data.step === 0) {
    _push(`<div>`);
    if ($data.templates.length > 0) {
      _push(`<div class="row"><div class="col-12"><div class="card border-success mb-3 mt-3"><div class="card-body"><label class="form-label" id="bot-level-2">Выберите шаблон!</label><select class="form-control" aria-label="Шаблон бота" aria-describedby="bot-level-2"><!--[-->`);
      ssrRenderList($data.templates, (bot, index) => {
        _push(`<option${ssrRenderAttr("value", bot.id)}>${ssrInterpolate(bot.bot_domain)}</option>`);
      });
      _push(`<!--]--></select></div></div></div></div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`<div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Доменное имя бота из BotFather</label><input type="text" class="form-control" placeholder="Имя бота" aria-label="Имя бота"${ssrRenderAttr("value", $data.botForm.bot_domain)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="bot-description">Описание бота</label><textarea type="text" class="form-control" placeholder="Текстовое описание бота" aria-label="Текстовое описание бота" maxlength="255" aria-describedby="bot-description" required>${ssrInterpolate($data.botForm.description)}</textarea></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-token">Токен бота</label><input type="text" class="form-control" placeholder="Токен" aria-label="Токен"${ssrRenderAttr("value", $data.botForm.bot_token)} maxlength="255" aria-describedby="bot-token" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-token-dev">Токен бота (для тестирования)</label><input type="text" class="form-control" placeholder="Токен" aria-label="Токен"${ssrRenderAttr("value", $data.botForm.bot_token_dev)} maxlength="255" aria-describedby="bot-token-dev"></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-order-channel">Канал для заказов</label><input type="text" class="form-control" placeholder="Номер канала" aria-label="Номер канала"${ssrRenderAttr("value", $data.botForm.order_channel)} maxlength="255" aria-describedby="bot-order-channel" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-main-channel">Канал для постов (рекламный)</label><input type="text" class="form-control" placeholder="Номер канала" aria-label="Номер канала"${ssrRenderAttr("value", $data.botForm.main_channel)} maxlength="255" aria-describedby="bot-main-channel" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-balance">Баланс бота, руб</label><input type="number" class="form-control" placeholder="Баланс" aria-label="Баланс"${ssrRenderAttr("value", $data.botForm.balance)} min="0" aria-describedby="bot-balance" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-tax-per-day">Списание за сутки, руб</label><input type="number" class="form-control" placeholder="Списание" aria-label="Списание"${ssrRenderAttr("value", $data.botForm.tax_per_day)} min="0" aria-describedby="bot-tax-per-day" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-1">Уровень 1 CashBack, %</label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", $data.botForm.level_1)} maxlength="255" aria-describedby="bot-level-1" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-2">Уровень 2 CashBack, %</label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", $data.botForm.level_2)} maxlength="255" aria-describedby="bot-level-2" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-3">Уровень 3 CashBack, %</label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", $data.botForm.level_3)} maxlength="255" aria-describedby="bot-level-3" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="bot-maintenance-message">Сообщение для режима тех. работ</label><textarea type="text" class="form-control" placeholder="Текстовое сообщение" aria-label="Текстовое сообщение" maxlength="255" aria-describedby="bot-maintenance-message" required>${ssrInterpolate($data.botForm.maintenance_message)}</textarea></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Информационная ссылка: создайте контент в <a target="_blank" href="https://telegra.ph">https://telegra.ph</a></h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><div class="row"><div class="col-12"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка ресурс telegraph" aria-label="Ссылка ресурс telegraph" maxlength="255"${ssrRenderAttr("value", $data.botForm.info_link)}${ssrRenderAttr("aria-describedby", "bot-info-link")}></div></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Ссылки на соц. сети</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><!--[-->`);
    ssrRenderList($data.botForm.social_links, (item, index) => {
      _push(`<div class="row"><div class="col-5"><div class="mb-3"><input type="text" class="form-control" placeholder="Название ссылки" aria-label="Название ссылки" maxlength="255"${ssrRenderAttr("value", $data.botForm.social_links[index].title)}${ssrRenderAttr("aria-describedby", "bot-social-link-" + index)} required></div></div><div class="col-5"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка на соц.сеть" aria-label="Ссылка на соц.сеть" maxlength="255"${ssrRenderAttr("value", $data.botForm.social_links[index].url)}${ssrRenderAttr("aria-describedby", "bot-social-link-" + index)} required></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
    });
    _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще ссылку </button></div></div></div></div></div></div><div class="row"><div class="col-12 mb-3"><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="bot-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="bot-photos" multiple accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
    if ($data.botForm.photos.length > 0) {
      _push(`<!--[-->`);
      ssrRenderList($data.botForm.photos, (img, index) => {
        _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(img).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
      });
      _push(`<!--]-->`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div></div></div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($data.step === 1) {
    _push(`<div><div class="row"><div class="col-12 mb-3"><div class="alert alert-warning" role="alert"> Если меняете текст в &quot;Нижней клавиатуре&quot;, то найдите и поменяйте его также в разделе &quot;Команды бота&quot; </div></div>`);
    if ($data.botForm.keyboards) {
      _push(`<!--[-->`);
      ssrRenderList($data.botForm.keyboards, (slug, index) => {
        _push(`<div class="col-12 mb-3"><div class="card"><div class="card-body"><div class="row"><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Тип</label><select${ssrIncludeBooleanAttr(true) ? " disabled" : ""} class="form-control"><option value="reply">Нижняя клавиатура</option><option value="inline">Встроенная клавиатура</option></select></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Мнемоническое имя</label><input type="text" class="form-control" placeholder="Мнемоническое имя"${ssrIncludeBooleanAttr(true) ? " disabled" : ""} aria-label="Мнемоническое имя"${ssrRenderAttr("value", $data.botForm.keyboards[index].slug)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="bot-domain">JSON-код клавиатуры</label>`);
        _push(ssrRenderComponent(_component_Vue3JsonEditor, {
          mode: "code",
          modelValue: $data.botForm.keyboards[index].menu,
          "onUpdate:modelValue": ($event) => $data.botForm.keyboards[index].menu = $event,
          "show-btns": false,
          expandedOnStart: true,
          onClick: ($event) => $data.selectMenuIndex = index,
          onJsonChange: $options.onJsonChange
        }, null, _parent));
        _push(`</div><div class="row"><div class="col-12"><h6>Демонстрация меню</h6></div><div class="col-12"><!--[-->`);
        ssrRenderList($data.botForm.keyboards[index].menu, (row, rowIndex) => {
          _push(`<div class="row"><!--[-->`);
          ssrRenderList(row, (col, colIndex) => {
            _push(`<div class="col"><button type="button" class="btn btn-outline-primary w-100 mb-2">${ssrInterpolate(col.text)}</button></div>`);
          });
          _push(`<!--]--></div>`);
        });
        _push(`<!--]--></div></div></div></div></div></div></div>`);
      });
      _push(`<!--]-->`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($data.step === 2) {
    _push(`<div><div class="row"><div class="col-12 mb-3"><div class="alert alert-warning" role="alert"> Если вы боитесь последствий модификации команды, то продублируйте нужную и внесите коррективы! Работать будут обе команды как оригинал, так и дубль! </div></div>`);
    if ($data.botForm.slugs.length > 0) {
      _push(`<!--[-->`);
      ssrRenderList($data.botForm.slugs, (slug, index) => {
        _push(`<div class="col-12 mb-3"><div class="card"><div class="card-body"><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success mr-2"> Дублировать </button><button type="button" class="btn btn-outline-danger"> Удалить </button></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Команда</label><input type="text" class="form-control" placeholder="Команда" aria-label="Команда"${ssrRenderAttr("value", $data.botForm.slugs[index].command)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Мнемоническое имя</label><input type="text" class="form-control"${ssrIncludeBooleanAttr(true) ? " disabled" : ""} placeholder="Мнемоническое имя" aria-label="Мнемоническое имя"${ssrRenderAttr("value", $data.botForm.slugs[index].slug)} maxlength="255" aria-describedby="bot-domain" required></div></div></div></div></div></div>`);
      });
      _push(`<!--]-->`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="row"><div class="col-12"><button type="submit" class="btn btn-outline-success w-100 p-3">Добавить бота </button></div></div></form><!--]-->`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Bot.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Bot = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$2 = {
  props: ["botId"],
  data() {
    return {
      menus: [],
      menuForm: {
        title: null,
        description: null,
        image: null,
        info_link: null,
        bot_id: null
      }
    };
  },
  methods: {
    getPhoto(imgObject) {
      return { imageUrl: URL.createObjectURL(imgObject) };
    },
    removePhoto() {
      this.menuForm.image = null;
    },
    removeItem(index) {
      this.menus.splice(index, 1);
    },
    submitMenus() {
      this.menus.forEach((menu) => {
        let data = new FormData();
        Object.keys(menu).forEach((key) => {
          const item = menu[key] || "";
          if (typeof item === "object")
            data.append(key, JSON.stringify(item));
          else
            data.append(key, item);
        });
        data.append("preview", menu.image);
        data.delete("image");
        this.$store.dispatch("createImageMenu", {
          menuForm: data
        }).then((response) => {
          this.$emit("callback", response.data);
          this.$notify("Меню успешно создано и сохранено");
        }).catch((err) => {
        });
      });
    },
    addImageMenu() {
      this.menuForm.bot_id = this.botId;
      this.menus.push(this.menuForm);
      this.$notify("Меню успешно добавлено в список");
      this.menuForm = {
        title: null,
        description: null,
        image: null,
        info_link: null,
        bot_id: null
      };
    },
    onChangePhotos(e) {
      const file = e.target.files[0];
      this.menuForm.image = file;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _directive_lazy = resolveDirective("lazy");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))}><div class="card-body"><form><h6>Графическое Меню к боту #${ssrInterpolate($props.botId || "Не установлен")}</h6><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-address">Название меню</label><input type="text" class="form-control" placeholder="Название меню" aria-label="Название меню" maxlength="255"${ssrRenderAttr("value", $data.menuForm.title)} aria-describedby="menu-address" required></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-description">Описание меню</label><textarea type="text" class="form-control" placeholder="Описание меню" aria-label="Описание меню" maxlength="255" aria-describedby="menu-description" required>${ssrInterpolate($data.menuForm.description)}</textarea></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-address">Ссылка на страницу в <a target="_blank" href="https://telegra.ph">telegra.ph</a></label><input type="text" class="form-control" placeholder="Информационная ссылка" aria-label="Информационная ссылка" maxlength="255"${ssrRenderAttr("value", $data.menuForm.info_link)} aria-describedby="menu-info-link"></div></div></div><div class="row"><div class="col-12 mb-3"><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="menu-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="menu-photos" accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.menuForm.image) {
    _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto($data.menuForm.image).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div><div class="row"><div class="col-12"><button class="btn btn-outline-success w-100" type="submit">Добавить меню </button></div></div></form><div class="row">`);
  if ($data.menus.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.menus, (menu, index) => {
      _push(`<div class="col-12 mt-3"><div class="card"><div class="card-header d-flex justify-content-between"><h6>Название <strong>${ssrInterpolate(menu.title || "Не указано")}</strong></h6><a class="cursor-pointer">Удалить</a></div><div class="card-body"><p>${ssrInterpolate(menu.description || "Не указано")}</p><p> ссылка на меню из telegra.ph ${ssrInterpolate(menu.info_link || "Не указано")}</p><div class="w-100 d-flex">`);
      if (menu.image) {
        _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(menu.image).imageUrl))}></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="row mt-3"><div class="col-12"><button${ssrIncludeBooleanAttr($data.menus.length === 0) ? " disabled" : ""} class="btn btn-outline-primary p-3 w-100">Сохранить меню для заведения</button></div></div></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/ImageMenu.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const ImageMenu = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const __default__ = {
  data() {
    return {
      step: 0,
      companyId: null,
      botId: null
    };
  },
  computed: {
    ...mapGetters(["getErrors"])
  },
  watch: {
    getErrors: function(newVal, oldVal) {
      Object.keys(newVal).forEach((key) => {
        this.$notify({
          title: "Конструктор ботов",
          text: newVal[key],
          type: "warn"
        });
      });
    }
  },
  methods: {
    reset() {
      this.step = 0;
      this.companyId = null;
      this.botId = null;
    },
    skip() {
      this.step++;
    },
    companyCallback(company) {
      console.log("company", company);
      this.companyId = company.id;
      this.step++;
    },
    locationCallback(location) {
      console.log("location", location);
      this.step++;
    },
    botCallback(bot) {
      console.log("bot", bot);
      this.botId = bot.id;
      this.step++;
    },
    imageMenuCallback(imageMenu) {
      this.step++;
    }
  }
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Constructor",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row">`);
      if (_ctx.step === 0) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 1: найдите или создайте компанию</h3></div>`);
        if (_ctx.step === 0) {
          _push(`<div class="card-body"><h5 class="mt-2 mb-2">Найдите существующую компанию</h5>`);
          _push(ssrRenderComponent(_sfc_main$5, { onCallback: _ctx.companyCallback }, null, _parent));
          _push(`<h5 class="mb-2">или создайте новую компанию</h5>`);
          _push(ssrRenderComponent(Company, { onCallback: _ctx.companyCallback }, null, _parent));
          _push(`</div>`);
        } else {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Шаг создания компании пройден! Далее следует приступить к следующим шагам! </div></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 1) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 2: Добавьте локации заведений (не объязательно)</h3></div>`);
        if (_ctx.step === 1) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Если нет необходимости в локациях, вы можете пропустить данный шаг <button type="button" class="btn btn-primary">Пропустить </button> или же вы можете вернуться на прошлый шаг <button type="button" class="btn btn-primary">Начать заново </button></div>`);
          if (_ctx.companyId) {
            _push(ssrRenderComponent(Location, {
              "company-id": _ctx.companyId,
              onCallback: _ctx.locationCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 1) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 1) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Вы создалии локации в завдении! Приступаем к следующим шагам! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 2) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 3: Добавьте бота </h3></div>`);
        if (_ctx.step === 2) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> При необходимости вы можете начать по новой <button type="button" class="btn btn-primary">Начать заново </button></div>`);
          if (_ctx.companyId) {
            _push(ssrRenderComponent(Bot, {
              "company-id": _ctx.companyId,
              onCallback: _ctx.botCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 2) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 2) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Бот создан! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 3) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 4: Добавьте в бота меню</h3></div>`);
        if (_ctx.step === 3) {
          _push(`<div class="card-body">`);
          if (_ctx.botId) {
            _push(ssrRenderComponent(ImageMenu, {
              "bot-id": _ctx.botId,
              onCallback: _ctx.imageMenuCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 3) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 3) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Все шаги выполнены <button type="button" class="btn btn-primary">Начать заново </button></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 4) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 5: Обновите зависимости веб-хуков</h3></div>`);
        if (_ctx.step === 3) {
          _push(`<div class="card-body"><a target="_blank" class="btn btn-outline-success w-100" href="/bot/register-webhooks">Обновить</a></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Constructor.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Dashboard_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_notifications = resolveComponent("notifications");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row">`);
      _push(ssrRenderComponent(_component_notifications, { position: "top right" }, null, _parent));
      _push(`</div><div class="row"><div class="col-12 pt-3 pb-3">`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
