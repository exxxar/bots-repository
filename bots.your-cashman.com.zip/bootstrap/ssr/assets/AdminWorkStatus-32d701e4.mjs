import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { U as UserInfo } from "./UserInfo-b199f12b.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const __default__ = {
  data() {
    return {
      loading: false
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {
    selfRemove() {
      this.loading = true;
      this.$store.dispatch("selfRemove", {
        dataObject: {
          bot_id: this.botUser.bot_id,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    workStateChange() {
      this.loading = true;
      this.$store.dispatch("workStateChange", {
        dataObject: {
          bot_id: this.botUser.bot_id,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "AdminWorkStatus",
  __ssrInlineRender: true,
  props: {
    user: {
      type: Object
    },
    botUser: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.botUser.is_admin) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row mb-2"><div class="col-12">`);
        _push(ssrRenderComponent(UserInfo, { "bot-user": __props.botUser }, null, _parent));
        _push(`</div></div><div class="row"><div class="col-12"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} class="btn btn-outline-primary w-100 mb-2">`);
        if (__props.botUser.is_work) {
          _push(`<span>Завершить рабочую смену</span>`);
        } else {
          _push(`<!---->`);
        }
        if (!__props.botUser.is_work) {
          _push(`<span>Начать рабочую смены</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</button></div><div class="col-12"><button${ssrIncludeBooleanAttr(_ctx.loading || !__props.botUser.is_admin) ? " disabled" : ""} class="btn btn-outline-primary w-100 mb-2"> Разжаловать себя из администраторов </button></div></div></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row"><div class="alert alert-warning" role="alert"> Вы не являетесь администратором </div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/AdminWorkStatus.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
