import { resolveComponent, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, toDisplayString, useSSRContext, mergeProps } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderAttrs } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const Chat_vue_vue_type_style_index_0_lang = "";
const _sfc_main$1 = {
  props: ["domain"],
  watch: {
    messages: function(newVal) {
      this.$nextTick(function() {
        var container = this.$el.querySelector("#scroll-area");
        container.scrollTop = container.scrollHeight + 120;
      });
    }
  },
  data() {
    return {
      is_active: true,
      is_keyboard: true,
      text: "/start",
      messages: [],
      buttons: [],
      dataForm: {
        message: null,
        query: null,
        user: {
          id: 484698703,
          first_name: "Test",
          last_name: "test",
          username: "eessdsdsd"
        }
      }
    };
  },
  methods: {
    buttonSend(button) {
      this.dataForm.message = null;
      this.dataForm.query = button.text || button || null;
      this.send();
    },
    send() {
      axios.post("/web/" + this.domain, this.dataForm).then((resp) => {
        console.log("data", resp);
        let data = resp.data;
        data.forEach((item) => {
          if (item.text)
            this.messages.push({ text: item.text, result: true, type: 0, keyboard: null, photo: null });
          if (item.photo)
            this.messages.push({ text: item.caption, result: true, type: 1, photo: item.photo });
          let tmp = JSON.parse(item.reply_markup);
          if (item.reply_markup) {
            if (tmp.keyboard) {
              this.buttons = tmp.keyboard;
              this.is_keyboard = true;
            }
            if (tmp.inline_keyboard) {
              console.log(tmp.inline_keyboard);
              this.messages.push({ result: true, type: 2, keyboard: tmp.inline_keyboard });
            }
          }
        });
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_perfect_scrollbar = resolveComponent("perfect-scrollbar");
  _push(`<!--[--><h3>Заголовок чата</h3><a><i class="fa fa-times" aria-hidden="true"></i></a>`);
  _push(ssrRenderComponent(_component_perfect_scrollbar, { class: "scroll-area" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<ul${_scopeId}><!--[-->`);
        ssrRenderList($data.messages, (message) => {
          _push2(`<li${_scopeId}>`);
          if (message.type === 0) {
            _push2(`<div${_scopeId}>`);
            if (message.result) {
              _push2(`<div class="incoming"${_scopeId}><p${_scopeId}>${message.text}</p></div>`);
            } else {
              _push2(`<div class="outcoming"${_scopeId}><p${_scopeId}>${message.text}</p></div>`);
            }
            _push2(`</div>`);
          } else {
            _push2(`<!---->`);
          }
          if (message.type === 1) {
            _push2(`<div${_scopeId}><div class="incoming"${_scopeId}><img${ssrRenderAttr("src", message.photo)} alt=""${_scopeId}><p${_scopeId}>${message.text}</p></div></div>`);
          } else {
            _push2(`<!---->`);
          }
          if (message.type === 2) {
            _push2(`<div${_scopeId}><div class="incoming"${_scopeId}><ul${_scopeId}><!--[-->`);
            ssrRenderList(message.keyboard, (row) => {
              _push2(`<li class="row"${_scopeId}><!--[-->`);
              ssrRenderList(row, (button) => {
                _push2(`<div class="btn-wrapper"${_scopeId}>`);
                if (button.callback_data) {
                  _push2(`<button${_scopeId}>${ssrInterpolate(button.text)}</button>`);
                } else {
                  _push2(`<!---->`);
                }
                if (button.url) {
                  _push2(`<a${ssrRenderAttr("href", button.url)} target="_blank"${_scopeId}>${ssrInterpolate(button.text)}</a>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]--></li>`);
            });
            _push2(`<!--]--></ul></div></div>`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`</li>`);
        });
        _push2(`<!--]--></ul>`);
      } else {
        return [
          createVNode("ul", null, [
            (openBlock(true), createBlock(Fragment, null, renderList($data.messages, (message) => {
              return openBlock(), createBlock("li", null, [
                message.type === 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                  message.result ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "incoming"
                  }, [
                    createVNode("p", {
                      innerHTML: message.text
                    }, null, 8, ["innerHTML"])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "outcoming"
                  }, [
                    createVNode("p", {
                      innerHTML: message.text
                    }, null, 8, ["innerHTML"])
                  ]))
                ])) : createCommentVNode("", true),
                message.type === 1 ? (openBlock(), createBlock("div", { key: 1 }, [
                  createVNode("div", { class: "incoming" }, [
                    createVNode("img", {
                      src: message.photo,
                      alt: ""
                    }, null, 8, ["src"]),
                    createVNode("p", {
                      innerHTML: message.text
                    }, null, 8, ["innerHTML"])
                  ])
                ])) : createCommentVNode("", true),
                message.type === 2 ? (openBlock(), createBlock("div", { key: 2 }, [
                  createVNode("div", { class: "incoming" }, [
                    createVNode("ul", null, [
                      (openBlock(true), createBlock(Fragment, null, renderList(message.keyboard, (row) => {
                        return openBlock(), createBlock("li", { class: "row" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(row, (button) => {
                            return openBlock(), createBlock("div", { class: "btn-wrapper" }, [
                              button.callback_data ? (openBlock(), createBlock("button", {
                                key: 0,
                                onClick: ($event) => $options.buttonSend(button.callback_data)
                              }, toDisplayString(button.text), 9, ["onClick"])) : createCommentVNode("", true),
                              button.url ? (openBlock(), createBlock("a", {
                                key: 1,
                                href: button.url,
                                target: "_blank"
                              }, toDisplayString(button.text), 9, ["href"])) : createCommentVNode("", true)
                            ]);
                          }), 256))
                        ]);
                      }), 256))
                    ])
                  ])
                ])) : createCommentVNode("", true)
              ]);
            }), 256))
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<form class="message"><input type="text" placeholder="text"${ssrRenderAttr("value", $data.dataForm.message)}><div class="mini-btn"><button type="submit"> Отправть </button></div></form>`);
  if ($data.buttons.length > 0 && $data.is_keyboard) {
    _push(`<div class="buttons"><ul><!--[-->`);
    ssrRenderList($data.buttons, (row) => {
      _push(`<li class="row"><div class="col-12 d-flex justify-content-center"><!--[-->`);
      ssrRenderList(row, (button) => {
        _push(`<button class="btn btn-outline-primary w-100 m-1">${ssrInterpolate(button.text)}</button>`);
      });
      _push(`<!--]--></div></li>`);
    });
    _push(`<!--]--></ul></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<!--]-->`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Chat/Chat.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Chat = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const __default__ = {
  data() {
    return {
      load: false,
      confirm: false,
      vipForm: {
        name: null,
        phone: null,
        email: null,
        birthday: null,
        city: null,
        country: null,
        address: null,
        sex: true
      }
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {
    submit() {
      this.loading = true;
      this.$store.dispatch("saveVip", {
        dataObject: {
          bot_id: this.bot.id,
          tg: this.tgUser,
          form: this.vipForm
        }
      }).then((resp) => {
        this.loading = false;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "ChatWindow",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    },
    botUser: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.bot) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container-fluid pt-3 pb-3" }, _attrs))}><div class="row"><div class="col-12">`);
        _push(ssrRenderComponent(Chat, {
          domain: __props.bot.bot_domain
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/ChatWindow.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
