import { resolveDirective, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderAttr, ssrInterpolate, ssrGetDynamicModelProps, ssrIncludeBooleanAttr, ssrLooseEqual, ssrLooseContain } from "vue/server-renderer";
const VipForm_vue_vue_type_style_index_0_lang = "";
const __default__ = {
  data() {
    return {
      load: false,
      confirm: false,
      step: 0,
      vipForm: {
        name: null,
        phone: null,
        email: null,
        birthday: null,
        city: null,
        country: null,
        address: null,
        sex: true
      }
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {
    nextStep() {
      this.step++;
    },
    submit() {
      this.loading = true;
      this.$store.dispatch("saveVip", {
        dataObject: {
          bot_id: this.bot.id,
          tg: this.tgUser,
          form: this.vipForm
        }
      }).then((resp) => {
        this.loading = false;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "VipForm",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    },
    botUser: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_lazy = resolveDirective("lazy");
      const _directive_mask = resolveDirective("mask");
      let _temp0;
      if (!__props.botUser.is_vip) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container pt-3 pb-3" }, _attrs))}>`);
        if (_ctx.step === 0) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>Приветствую тебя, <strong>Дорогой друг!</strong> Я хочу поздаврить тебя и дать возможность получать неограниченные преимушества нашего сервиса! Для начала нам нужно с тобой познакомится - это поможет сделать использование сервиса более кофортным и взаимовыгодным!</em></p><h6 class="text-center">Как мне к тебе обращаться?</h6><div class="input-group mb-3"><input type="text" class="form-control text-center p-3" placeholder="Петров Петр Семенович" aria-label="vipForm-name"${ssrRenderAttr("value", _ctx.vipForm.name)} aria-describedby="vipForm-name" required></div><button class="btn btn-outline-primary p-3 w-100"> Следующий шаг </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step === 1) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>- Отлично, <strong>${ssrInterpolate(_ctx.vipForm.name)}</strong>! А теперь, чтобы ты мог пользоваться всеми моими функциями, мне нужен твой номер телефона. Можешь ввести его?</em></p><h6 class="text-center">Введи свой номер телефона</h6><div class="input-group mb-3"><input${ssrRenderAttrs((_temp0 = mergeProps({
            type: "text",
            class: "form-control p-3 text-center",
            value: _ctx.vipForm.phone,
            placeholder: "+7(000)000-00-00",
            "aria-label": "vipForm-phone",
            "aria-describedby": "vipForm-phone",
            required: ""
          }, ssrGetDirectiveProps(_ctx, _directive_mask, "+7(###)###-##-##")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, _ctx.vipForm.phone))))}></div><button class="btn btn-outline-primary p-3 w-100"> Следующий шаг </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step === 2) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>Чтобы я мог обращаться к тебе правильно, скажи мне, какого ты пола?</em></p><h6 class="text-center">Ты парень или девушка?</h6><div class="input-group mb-3 mt-3 w-100 d-flex justify-content-center"><div class="btn-group w-100" role="group" aria-label="vipForm-sex"><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.vipForm.sex, null)) ? " checked" : ""} class="btn-check" name="sex-radio-btn" id="sex-radio-btn-1" autocomplete="off" required><label class="btn btn-outline-primary p-3" for="sex-radio-btn-1">Парень</label><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.vipForm.sex, null)) ? " checked" : ""} class="btn-check" name="sex-radio-btn" id="sex-radio-btn-2" autocomplete="off" required><label class="btn btn-outline-primary p-3" for="sex-radio-btn-2">Девушка</label></div></div><button class="btn btn-outline-primary p-3 w-100"> Следующий шаг </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step === 3) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>Для того, чтобы я мог поздравлять тебя с днем рождения и сделать тебе приятно, мне нужно знать, когда он у тебя</em></p><h6 class="text-center">Введи свой день рождения</h6><div class="input-group mb-3"><input type="date" class="form-control p-3"${ssrRenderAttr("value", _ctx.vipForm.birthday)} aria-label="vipForm-birthday" aria-describedby="vipForm-birthday" required></div><button class="btn btn-outline-primary p-3 w-100"> Следующий шаг </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step === 4) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>Чтобы я мог показывать тебе информацию, актуальную для твоего города, мне нужно знать, где ты живешь.</em></p><h6 class="text-center">Какой у тебя город?</h6><div class="input-group mb-3"><input type="text"${ssrRenderAttr("value", _ctx.vipForm.city)} list="datalistCityOptions" class="form-control p-3" placeholder="Краснодар" aria-label="vipForm-city" aria-describedby="vipForm-city" required><datalist id="datalistCityOptions"><option value="Краснодар"></option><option value="Ростов-на-Дону"></option><option value="Таганрог"></option><option value="Донецк"></option><option value="Москва"></option></datalist></div><button class="btn btn-outline-primary p-3 w-100"> Следующий шаг </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step === 5) {
          _push(`<form class="row"><div class="col-12 d-flex justify-content-center mb-3"><div class="img-avatar"><img${ssrRenderAttrs(mergeProps({ class: "img-avatar" }, ssrGetDirectiveProps(_ctx, _directive_lazy, "https://your-cashman.com/Image/IconSmall.png")))}></div></div><div class="col-12"><p class="mb-3"><em>Отлично! Теперь, прежде чем продолжить, пожалуйста, прочти мои условия использования и дай свое согласие на их принятие.</em></p><h6 class="text-center">Последний шаг</h6><div class="card border-success mb-3"><div class="card-body"><p>Перед отправкой данных ознакомься с <a href="#">правилами нашего сервиса</a> и с <a href="#">политикой конфиденциальности</a>.</p><div class="form-check form-switch"><input class="form-check-input"${ssrIncludeBooleanAttr(Array.isArray(_ctx.confirm) ? ssrLooseContain(_ctx.confirm, null) : _ctx.confirm) ? " checked" : ""} type="checkbox" role="switch" id="confirm"><label class="form-check-label" for="confirm">`);
          if (!_ctx.vipForm.sex) {
            _push(`<span>С правилами озакномилась</span>`);
          } else {
            _push(`<!---->`);
          }
          if (_ctx.vipForm.sex) {
            _push(`<span>С правилами ознакомлен</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</label></div></div></div><button type="button" class="btn btn-outline-primary w-100 p-3 mb-3">Исправить ошибки </button><button type="submit"${ssrIncludeBooleanAttr(!_ctx.confirm || _ctx.load) ? " disabled" : ""} class="btn btn-outline-success w-100 p-3">Отправить анкету </button></div></form>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container pt-3 pb-3" }, _attrs))}><div class="row"><div class="col-12"><div class="card border-success"><div class="card-body"> Поздравляем! Вы являетесь нашим VIP-пользователеме! Вам доступны следующие возможности: <ul><li>Накопление CashBack за покупки</li><li>Оплата товаров через CashBak</li><li>Реферальная программа</li></ul></div></div></div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/VipForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
