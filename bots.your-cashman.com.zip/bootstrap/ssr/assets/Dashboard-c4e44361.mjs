import { useSSRContext, resolveComponent, resolveDirective, withCtx, createVNode, createTextVNode, mergeProps } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrGetDirectiveProps, ssrGetDynamicModelProps, ssrIncludeBooleanAttr, ssrRenderStyle, ssrLooseContain, ssrRenderClass } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
import { P as Pagination } from "./Pagination-05b9527c.mjs";
import { mapGetters } from "vuex";
import { Vue3JsonEditor } from "vue3-json-editor";
const Company_vue_vue_type_style_index_0_lang = "";
const _sfc_main$d = {
  props: ["company"],
  data() {
    return {
      load: false,
      photo: null,
      removedImage: null,
      companyForm: {
        id: null,
        title: null,
        slug: null,
        description: null,
        address: null,
        phones: [""],
        links: [""],
        email: null,
        schedule: [],
        manager: null
      }
    };
  },
  mounted() {
    if (this.company)
      this.$nextTick(() => {
        this.companyForm = {
          id: this.company.id || null,
          title: this.company.title || null,
          slug: this.company.slug || null,
          image: this.company.image || null,
          description: this.company.description || null,
          address: this.company.address || null,
          phones: this.company.phones || [""],
          links: this.company.links || [""],
          email: this.company.email || null,
          schedule: this.company.schedule || [],
          manager: this.company.manager || null
        };
      });
  },
  methods: {
    getPhoto() {
      return { imageUrl: URL.createObjectURL(this.photo) };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      this.photo = files[0];
      this.companyForm.image = null;
    },
    schedulePlaceholder() {
      if (this.companyForm.schedule.length > 0) {
        this.companyForm.schedule = [];
      } else {
        this.companyForm.schedule = [
          "Понедельник - с 8:00 до 20:00",
          "Вторник - с 8:00 до 20:00",
          "Среда - с 8:00 до 20:00",
          "Четверг - с 8:00 до 20:00",
          "Пятница - с 8:00 до 20:00",
          "Суббота - с 8:00 до 20:00",
          "Воскресенье - выходной"
        ];
      }
    },
    removeCompanyImage() {
      this.removedImage = this.companyForm.image;
      this.companyForm.image = null;
    },
    addItem(name) {
      this.companyForm[name].push("");
    },
    removeItem(name, index) {
      this.companyForm[name].splice(index, 1);
    },
    submitForm() {
      let data = new FormData();
      Object.keys(this.companyForm).forEach((key) => {
        const item = this.companyForm[key] || "";
        if (typeof item === "object")
          data.append(key, JSON.stringify(item));
        else
          data.append(key, item);
      });
      data.append("company_logo", this.photo);
      if (this.removedImage != null)
        data.append("removed_image", this.removedImage);
      this.$store.dispatch(
        this.companyForm.id === null ? "createCompany" : "updateCompany",
        {
          companyForm: data
        }
      ).then((response) => {
        this.$emit("callback", response.data);
        this.$notify("Компания успешно создана");
      }).catch((err) => {
      });
    }
  }
};
function _sfc_ssrRender$4(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Popper = resolveComponent("Popper");
  const _directive_mask = resolveDirective("mask");
  const _directive_lazy = resolveDirective("lazy");
  let _temp0;
  _push(`<form${ssrRenderAttrs(_attrs)}><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="company-title">`);
  _push(ssrRenderComponent(_component_Popper, { content: "Название вашей компании" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(` Название компании <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Название" aria-label="Название"${ssrRenderAttr("value", $data.companyForm.title)} maxlength="255" aria-describedby="company-title" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-slug">`);
  _push(ssrRenderComponent(_component_Popper, null, {
    content: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div${_scopeId}>Название компании на АНГЛИЙСКОМ<br${_scopeId}> без пробелов! можно использовать _<br${_scopeId}> Должно быть уникальным! Не отображается пользователю. </div>`);
      } else {
        return [
          createVNode("div", null, [
            createTextVNode("Название компании на АНГЛИЙСКОМ"),
            createVNode("br"),
            createTextVNode(" без пробелов! можно использовать _"),
            createVNode("br"),
            createTextVNode(" Должно быть уникальным! Не отображается пользователю. ")
          ])
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(` Название компании латиницей (домен компании) <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Мнемоническое имя" aria-label="Мнемоническое имя"${ssrRenderAttr("value", $data.companyForm.slug)} maxlength="255" aria-describedby="company-slug" required></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-description">`);
  _push(ssrRenderComponent(_component_Popper, null, {
    content: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div${_scopeId}>Добавится в раздел &quot;О Нас&quot;</div>`);
      } else {
        return [
          createVNode("div", null, 'Добавится в раздел "О Нас"')
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(` Описание компании <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><textarea type="text" class="form-control" placeholder="Описание компании" aria-label="Описание компании" aria-describedby="company-description" required>${ssrInterpolate($data.companyForm.description)}</textarea></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-address">`);
  _push(ssrRenderComponent(_component_Popper, null, {
    content: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div${_scopeId}>Где находится главное заведение компании!<br${_scopeId}>Можно не указывать, т.к. есть еще &quot;Локации&quot;</div>`);
      } else {
        return [
          createVNode("div", null, [
            createTextVNode("Где находится главное заведение компании!"),
            createVNode("br"),
            createTextVNode('Можно не указывать, т.к. есть еще "Локации"')
          ])
        ];
      }
    }),
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
      } else {
        return [
          createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(` Основной адрес компании</label><input type="text" class="form-control" placeholder="Адрес" aria-label="Адрес" maxlength="255"${ssrRenderAttr("value", $data.companyForm.address)} aria-describedby="company-address"></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-email">Основная почта компании</label><input type="email" class="form-control" placeholder="Почтовый адрес" aria-label="Почтовый адрес" maxlength="255"${ssrRenderAttr("value", $data.companyForm.email)} aria-describedby="company-email"></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="company-manager">Менеджер компании</label><input type="text" class="form-control" placeholder="Имя менеджера" aria-label="Имя менеджера"${ssrRenderAttr("value", $data.companyForm.manager)} maxlength="255" aria-describedby="company-manager"></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Телефонные номера</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Телефонный номер</h6></div></div><!--[-->`);
  ssrRenderList($data.companyForm.phones, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input${ssrRenderAttrs((_temp0 = mergeProps({
      type: "text",
      class: "form-control",
      placeholder: "+7(000)000-00-00",
      "aria-label": "Номер телефона",
      maxlength: "255",
      value: $data.companyForm.phones[index],
      "aria-describedby": "company-phone-" + index
    }, ssrGetDirectiveProps(_ctx, _directive_mask, "+7(###)###-##-##")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, $data.companyForm.phones[index]))))}></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще номер </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Ссылки на соц. сети</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><!--[-->`);
  ssrRenderList($data.companyForm.links, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка на соц.сеть" aria-label="Ссылка на соц.сеть" maxlength="255"${ssrRenderAttr("value", $data.companyForm.links[index])}${ssrRenderAttr("aria-describedby", "company-link-" + index)}></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще ссылку </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>График работы</h6></div><div class="card-body"><div class="row"><div class="col-12 d-flex justify-content-between align-items-center"><h6>День недели </h6><a class="btn btn-link">Заполнить\\очистить</a></div></div><!--[-->`);
  ssrRenderList($data.companyForm.schedule, (item, index) => {
    _push(`<div class="row"><div class="col-10"><div class="mb-3"><input type="text" class="form-control" placeholder="День недели и время работы" aria-label="День недели и время работы" maxlength="255"${ssrRenderAttr("value", $data.companyForm.schedule[index])}${ssrRenderAttr("aria-describedby", "company-schedule-" + index)}></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
  });
  _push(`<!--]--><div class="row"><div class="col-12"><button type="button"${ssrIncludeBooleanAttr($data.companyForm.schedule.length === 7) ? " disabled" : ""} class="btn btn-outline-success w-100">Добавить еще время работы </button></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Логотип компании <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></h6></div><div class="card-body d-flex justify-content-start"><label for="photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"> + <input type="file" id="photos" accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.photo) {
    _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto().imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($data.companyForm.image) {
    _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, "/images/" + $data.companyForm.slug + "/" + $data.companyForm.image))}><div class="remove"><a>Удалить</a></div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div></div><div class="row"><div class="col-12"><button type="submit" class="btn btn-outline-success w-100 p-3">`);
  if ($data.companyForm.id === null) {
    _push(`<span>Создать компанию</span>`);
  } else {
    _push(`<span>Обновить компанию</span>`);
  }
  _push(`</button></div></div></form>`);
}
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Company.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const Company = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["ssrRender", _sfc_ssrRender$4]]);
const __default__$7 = {
  data() {
    return {
      loading: true,
      companies: [],
      search: null,
      companies_paginate_object: null
    };
  },
  computed: {
    ...mapGetters(["getCompanies", "getCompaniesPaginateObject"])
  },
  mounted() {
    this.loadCompanies();
  },
  methods: {
    selectCompany(company) {
      this.$emit("callback", company);
      this.$notify("Вы выбрали компанию из спика! Все остальные действия будут производится для этой компании.");
    },
    nextCompanies(index) {
      this.loadCompanies(index);
    },
    loadCompanies(page = 0) {
      this.loading = true;
      this.$store.dispatch("loadCompanies", {
        dataObject: {
          search: this.search
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.companies = this.getCompanies;
        this.companies_paginate_object = this.getCompaniesPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main$c = /* @__PURE__ */ Object.assign(__default__$7, {
  __name: "CompanyList",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="row"><div class="input-group mb-3"><input type="search" class="form-control" placeholder="Поиск компании" aria-label="Поиск компании"${ssrRenderAttr("value", _ctx.search)} aria-describedby="button-addon2"><button class="btn btn-outline-secondary" type="button" id="button-addon2">Найти</button></div></div>`);
      if (_ctx.companies.length > 0) {
        _push(`<div class="row"><div class="col-12 mb-3"><ul class="list-group w-100"><!--[-->`);
        ssrRenderList(_ctx.companies, (company, index) => {
          _push(`<li class="list-group-item">${ssrInterpolate(company.title || "Не указано")} (${ssrInterpolate(company.slug || "Не указано")})</li>`);
        });
        _push(`<!--]--></ul></div><div class="col-12">`);
        if (_ctx.companies_paginate_object) {
          _push(ssrRenderComponent(Pagination, {
            onPagination_page: _ctx.nextCompanies,
            pagination: _ctx.companies_paginate_object
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/CompanyList.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __default__$6 = {
  props: ["companyId", "editor"],
  data() {
    return {
      loading: true,
      bots: [],
      search: null,
      bots_paginate_object: null
    };
  },
  computed: {
    ...mapGetters(["getBots", "getBotsPaginateObject"])
  },
  mounted() {
    this.loadBots();
  },
  methods: {
    selectBot(bot) {
      this.$emit("callback", bot);
      this.$notify("Вы выбрали бота из списка! Все остальные действия будут производится для этого бота.");
    },
    nextBots(index) {
      this.loadBots(index);
    },
    loadBots(page = 0) {
      this.loading = true;
      this.$store.dispatch("loadBots", {
        dataObject: {
          companyId: this.companyId || null,
          search: this.search
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.bots = this.getBots;
        this.bots_paginate_object = this.getBotsPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main$b = /* @__PURE__ */ Object.assign(__default__$6, {
  __name: "BotList",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="row"><div class="input-group mb-3"><input type="search" class="form-control" placeholder="Поиск бота" aria-label="Поиск бота"${ssrRenderAttr("value", _ctx.search)} aria-describedby="button-addon2"><button class="btn btn-outline-secondary" type="button" id="button-addon2">Найти</button></div></div>`);
      if (_ctx.bots.length > 0) {
        _push(`<div class="row"><div class="col-12 mb-3"><ul class="list-group w-100">`);
        if (!__props.editor) {
          _push(`<li class="list-group-item active cursor-pointer">Создать нового бота</li>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--[-->`);
        ssrRenderList(_ctx.bots, (bot, index) => {
          _push(`<li class="list-group-item cursor-pointer">Выбрать для редактирования <strong>${ssrInterpolate(bot.bot_domain || "Не указано")}</strong></li>`);
        });
        _push(`<!--]--></ul></div><div class="col-12">`);
        if (_ctx.bots_paginate_object) {
          _push(ssrRenderComponent(Pagination, {
            onPagination_page: _ctx.nextBots,
            pagination: _ctx.bots_paginate_object
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<div class="row"><div class="col-12"><div class="alert alert-warning" role="alert"> У выбранной компании нет созданных ботов! </div></div></div>`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotList.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  props: ["companyId"],
  data() {
    return {
      locations: [],
      deletedLocations: [],
      locationForm: {
        lat: null,
        lon: null,
        address: null,
        description: null,
        location_channel: null,
        can_booking: false,
        photos: [],
        company_id: null
      }
    };
  },
  mounted() {
    this.loadLocationsByCompany();
  },
  methods: {
    loadLocationsByCompany() {
      this.$store.dispatch("loadLocationsByCompany", {
        companyId: this.companyId
      }).then((resp) => {
        this.locations = resp;
        console.log("!!!!", resp);
      }).catch(() => {
      });
    },
    getPhoto(imgObject) {
      return { imageUrl: URL.createObjectURL(imgObject) };
    },
    removePhoto(index) {
      this.locationForm.photos.splice(index, 1);
    },
    removeItem(index) {
      if (this.locations[index].id != null)
        this.deletedLocations.push(this.locations[index].id);
      this.locations.splice(index, 1);
    },
    submitLocations() {
      this.locations.forEach((location) => {
        let data = new FormData();
        Object.keys(location).forEach((key) => {
          const item = location[key] || "";
          if (typeof item === "object")
            data.append(key, JSON.stringify(item));
          else
            data.append(key, item);
        });
        if (location.photos) {
          for (let i = 0; i < location.photos.length; i++)
            data.append("files[]", location.photos[i]);
          data.delete("photos");
        }
        if (this.deletedLocations.length > 0)
          data.append("deleted_locations", JSON.stringify(this.deletedLocations));
        this.$store.dispatch("createLocation", {
          locationForm: data
        }).then((response) => {
          this.$emit("callback");
          this.$notify("Локация успешно созадана и сохранена");
        }).catch((err) => {
        });
      });
    },
    addLocation() {
      this.locationForm.company_id = this.companyId;
      this.locations.push(this.locationForm);
      this.$notify("Локация успешно добавлена в список. Не забудьте сохранить");
      this.locationForm = {
        lat: null,
        lon: null,
        address: null,
        description: null,
        location_channel: null,
        can_booking: false,
        photos: []
      };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      for (let i = 0; i < files.length; i++)
        this.locationForm.photos.push(files[i]);
    }
  }
};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _directive_mask = resolveDirective("mask");
  const _directive_lazy = resolveDirective("lazy");
  let _temp0, _temp1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))}><div class="card-body"><form><h6>Локации к компании #${ssrInterpolate($props.companyId || "Не установлен")}</h6><div class="row"><div class="col-12"><div class="form-check"><input class="form-check-input"${ssrIncludeBooleanAttr(Array.isArray($data.locationForm.can_booking) ? ssrLooseContain($data.locationForm.can_booking, "false") : $data.locationForm.can_booking) ? " checked" : ""} type="checkbox" value="false" id="flexCheckDefault"><label class="form-check-label" for="flexCheckDefault"> Можно бронировать столик </label></div></div><div class="col-12"><div class="mb-3"><label class="form-label" id="location-address"> Адрес заведения <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Адрес" aria-label="Адрес" maxlength="255"${ssrRenderAttr("value", $data.locationForm.address)} aria-describedby="location-address" required></div></div></div><div class="row"><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="location-lat"> Широта <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input${ssrRenderAttrs((_temp0 = mergeProps({
    type: "text",
    class: "form-control",
    placeholder: "##.######",
    "aria-label": "Широта",
    maxlength: "255",
    value: $data.locationForm.lat,
    "aria-describedby": "location-lat",
    required: ""
  }, ssrGetDirectiveProps(_ctx, _directive_mask, "##.######")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, $data.locationForm.lat))))}></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="location-lon"> Долгота <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input${ssrRenderAttrs((_temp1 = mergeProps({
    type: "text",
    class: "form-control",
    placeholder: "##.######",
    "aria-label": "Долгота",
    maxlength: "255",
    value: $data.locationForm.lon,
    "aria-describedby": "location-lon",
    required: ""
  }, ssrGetDirectiveProps(_ctx, _directive_mask, "##.######")), mergeProps(_temp1, ssrGetDynamicModelProps(_temp1, $data.locationForm.lon))))}></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="location-description"> Описание локации <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><textarea type="text" class="form-control" placeholder="Описание локации" aria-label="Описание локации" maxlength="255" aria-describedby="location-description" required>${ssrInterpolate($data.locationForm.description)}</textarea></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="location-channel">Телеграм канал локации</label><input type="text" class="form-control" placeholder="Номер телеграм канала" aria-label="Номер телеграм канала" maxlength="255"${ssrRenderAttr("value", $data.locationForm.location_channel)} aria-describedby="location-channel"></div></div></div><div class="row"><div class="col-12 mb-3"><h6>Фотографии локаций</h6><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="location-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="location-photos" multiple accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.locationForm.photos.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.locationForm.photos, (img, index) => {
      _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(img).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div><div class="row"><div class="col-12"><button class="btn btn-outline-success w-100" type="submit">Добавить локацию </button></div></div></form><div class="row">`);
  if ($data.locations.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.locations, (location, index) => {
      _push(`<div class="col-12 mt-3"><div class="card"><div class="card-header d-flex justify-content-between"><h6>Адрес локации <strong>${ssrInterpolate(location.address || "Не указано")}</strong> (ш:${ssrInterpolate(location.lat)},д:${ssrInterpolate(location.lon)}) `);
      if (location.can_booking) {
        _push(`<span class="badge bg-success">Можно забронировать столик</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</h6><a class="cursor-pointer">Удалить</a></div><div class="card-body"><p>Канал заведения <strong>${ssrInterpolate(location.location_channel)}</strong></p><p>${ssrInterpolate(location.description)}</p><h6>Фотографии локаций</h6>`);
      if (location.photos) {
        _push(`<div class="w-100 d-flex">`);
        if (location.photos.length > 0) {
          _push(`<!--[-->`);
          ssrRenderList(location.photos, (img, index2) => {
            _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(img).imageUrl))}></div>`);
          });
          _push(`<!--]-->`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (location.images) {
        _push(`<div class="w-100 d-flex">`);
        if (location.images.length > 0) {
          _push(`<!--[-->`);
          ssrRenderList(location.images, (img, index2) => {
            _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, "/images-by-company-id/" + $props.companyId + "/" + img))}></div>`);
          });
          _push(`<!--]-->`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="row mt-3"><div class="col-12"><button${ssrIncludeBooleanAttr($data.locations.length === 0 && $data.deletedLocations.length === 0) ? " disabled" : ""} class="btn btn-outline-primary p-3 w-100">Сохранить локации для заведения </button></div></div></div></div>`);
}
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Location.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const Location = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$9 = {
  props: ["editedKeyboard"],
  components: {
    Vue3JsonEditor
  },
  watch: {
    keyboard: {
      handler: function(newValue) {
        this.save();
      },
      deep: true
    }
  },
  data() {
    return {
      selectedRow: null,
      load: false,
      rowCount: 1,
      keyboard: []
    };
  },
  mounted() {
    if (this.editedKeyboard) {
      this.$nextTick(() => {
        this.keyboard = this.editedKeyboard.menu;
        console.log(this.keyboard);
      });
    }
  },
  methods: {
    save() {
      this.$emit("save", this.keyboard);
      this.load = true;
      this.$nextTick(() => {
        this.load = false;
      });
    },
    onJsonChange(value) {
      this.keyboard = value;
      this.save();
    },
    removeColFromRow(index) {
      if (this.keyboard[index].length > 1)
        this.keyboard[index].splice(this.keyboard[index].length - 1, 1);
      else
        this.keyboard.splice(index, 1);
      this.save();
    },
    addRowAbove() {
      this.addRow(true);
    },
    addRowBelow() {
      this.addRow(false);
    },
    addRow(above = false) {
      if (this.selectedRow == null) {
        this.keyboard.push([{
          text: "No Text"
        }]);
        this.selectedRow = null;
      } else {
        let index = !above ? this.selectedRow + 1 : this.selectedRow;
        this.keyboard.splice(index, 0, [{
          text: "No Text"
        }]);
      }
      this.save();
    },
    addColToRow(index) {
      this.keyboard[index].push({
        text: "No Text"
      });
      this.save();
    },
    removeCol(rowIndex, colIndex) {
      if (this.keyboard[rowIndex].length > 1)
        this.keyboard[rowIndex].splice(colIndex, 1);
      else
        this.keyboard.splice(1, 1);
      this.save();
    }
  }
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Vue3JsonEditor = resolveComponent("Vue3JsonEditor");
  _push(`<!--[--><div class="row"><div class="col-12">`);
  if ($data.selectedRow == null) {
    _push(`<button type="button" class="btn btn-primary mb-2">Добавить строку</button>`);
  } else {
    _push(`<!---->`);
  }
  if ($data.selectedRow != null) {
    _push(`<button type="button" class="btn btn-primary mb-2">Добавить строку выше</button>`);
  } else {
    _push(`<!---->`);
  }
  if ($data.selectedRow != null) {
    _push(`<button type="button" class="btn btn-primary mb-2 ml-2">Добавить строку ниже</button>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="col-12"><!--[-->`);
  ssrRenderList($data.keyboard, (row, rowIndex) => {
    _push(`<div class="row"><div class="col-1 d-flex justify-content-around p-1"><button type="button" class="btn btn-info">+ </button><button type="button" class="btn btn-danger">- </button></div><div class="col-11 d-flex justify-content-center p-1"><!--[-->`);
    ssrRenderList(row, (col, colIndex) => {
      _push(`<input type="text" class="btn btn-outline-primary w-100 m-1"${ssrRenderAttr("value", $data.keyboard[rowIndex][colIndex].text)}>`);
    });
    _push(`<!--]--></div></div>`);
  });
  _push(`<!--]--></div></div><div class="row"><div class="col-12"><label class="form-label" id="bot-domain">JSON-код клавиатуры</label>`);
  if (!$data.load) {
    _push(ssrRenderComponent(_component_Vue3JsonEditor, {
      mode: "code",
      modelValue: $data.keyboard,
      "onUpdate:modelValue": ($event) => $data.keyboard = $event,
      "show-btns": false,
      expandedOnStart: true,
      onJsonChange: $options.onJsonChange
    }, null, _parent));
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div><!--]-->`);
}
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotMenuConstructor.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const BotMenuConstructor = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["ssrRender", _sfc_ssrRender$2]]);
const __default__$5 = {
  props: ["keyboards"],
  data() {
    return {
      load: false,
      editedKeyboard: null,
      selectMenuIndex: null,
      editedButton: {
        oldTextVal: null,
        newTextVal: null,
        keyboardIndex: null,
        rowIndex: null,
        colIndex: null
      }
    };
  },
  methods: {
    saveKeyboard(keyboard) {
      this.keyboards[this.selectMenuIndex].menu = keyboard;
    },
    editKeyboard(keyboard, index) {
      this.load = true;
      this.$nextTick(() => {
        this.selectMenuIndex = index;
        this.editedKeyboard = keyboard;
        this.load = false;
      });
    },
    removeKeyboard(index) {
      this.$emit("remove", index);
    },
    editBtn(keyboardIndex, rowIndex, colIndex) {
      this.editedButton.oldTextVal = this.keyboards[keyboardIndex].menu[rowIndex][colIndex];
      this.editedButton.colIndex = colIndex;
      this.editedButton.rowIndex = rowIndex;
      this.editedButton.keyboardIndex = keyboardIndex;
      console.log(this.editedButton);
    }
  }
};
const _sfc_main$8 = /* @__PURE__ */ Object.assign(__default__$5, {
  __name: "BotMenuList",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="row"><div class="col-12 mb-3"><div class="alert alert-warning" role="alert"> Если меняете текст в &quot;Нижней клавиатуре&quot;, то найдите и поменяйте его также в разделе &quot;Команды бота&quot; </div></div>`);
      if (__props.keyboards) {
        _push(`<!--[-->`);
        ssrRenderList(__props.keyboards, (keyboard, index) => {
          _push(`<div class="col-12 mb-3"><div class="card"><div class="card-header"><button type="button" class="btn btn-outline-danger"> Удалить </button><button data-bs-toggle="modal" data-bs-target="#open-construct" type="button" class="btn btn-outline-success ml-2"> Конструктор </button></div><div class="card-body"><div class="row"><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Тип</label><select${ssrIncludeBooleanAttr(true) ? " disabled" : ""} class="form-control"><option value="reply">Нижняя клавиатура</option><option value="inline">Встроенная клавиатура</option></select></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Мнемоническое имя</label><input type="text" class="form-control" placeholder="Мнемоническое имя"${ssrIncludeBooleanAttr(true) ? " disabled" : ""} aria-label="Мнемоническое имя"${ssrRenderAttr("value", __props.keyboards[index].slug)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-12"><div class="row"><div class="col-12"><!--[-->`);
          ssrRenderList(__props.keyboards[index].menu, (row, rowIndex) => {
            _push(`<div class="row"><!--[-->`);
            ssrRenderList(row, (col, colIndex) => {
              _push(`<div class="col"><button type="button" class="btn btn-outline-primary w-100 mb-2">${ssrInterpolate(col.text)}</button></div>`);
            });
            _push(`<!--]--></div>`);
          });
          _push(`<!--]--></div></div></div></div></div></div></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="modal fade" id="open-construct" tabindex="-1" aria-labelledby="open-construct-label" aria-hidden="true"><div class="modal-dialog modal-fullscreen"><div class="modal-content"><div class="modal-header"><h1 class="modal-title fs-5" id="open-construct-label">Визуальный редактор клавиатуры</h1><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body">`);
      if (_ctx.editedKeyboard && !_ctx.load) {
        _push(ssrRenderComponent(BotMenuConstructor, {
          onSave: _ctx.saveKeyboard,
          "edited-keyboard": _ctx.editedKeyboard
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button></div></div></div></div><!--]-->`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotMenuList.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  props: ["slugs"],
  data() {
    return {
      allSlugs: [],
      slugForm: {
        command: null,
        comment: null,
        slug: null
      }
    };
  },
  mounted() {
    this.loadAllSlugs();
  },
  methods: {
    selectSlug(item) {
      this.slugForm.slug = item.slug;
      this.slugForm.comment = item.comment;
      this.slugForm.command = item.command;
    },
    duplicateSlug(index) {
      this.$emit("duplicate", index);
    },
    removeSlug(index) {
      this.$emit("remove", index);
    },
    loadAllSlugs() {
      this.$store.dispatch("loadAllSlugs").then((resp) => {
        console.log(resp);
        this.allSlugs = resp.data;
      });
    },
    addSlug() {
      const slug = this.slugForm;
      this.$emit("add", slug);
      this.slugForm.slug = null;
      this.slugForm.comment = null;
      this.slugForm.command = null;
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Popper = resolveComponent("Popper");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}><div class="col-12 mb-3"><div class="alert alert-warning" role="alert"> Если вы боитесь последствий модификации команды, то продублируйте нужную и внесите коррективы! Работать будут обе команды как оригинал, так и дубль! </div></div><div class="col-12">`);
  if ($data.allSlugs.length > 0) {
    _push(`<form class="card mb-3"><div class="card-body"><h6>Добавление нового скрипта в бота</h6><label class="form-label" id="bot-level-2"> Выберите скрипт <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><ul class="list-group" style="${ssrRenderStyle({ "overflow-y": "auto", "height": "300px", "padding": "10px" })}"><!--[-->`);
    ssrRenderList($data.allSlugs, (item, index) => {
      _push(`<li class="${ssrRenderClass([{ "active": $data.slugForm.slug === item.slug }, "list-group-item cursor-pointer"])}"><p>${ssrInterpolate(item.command)} (<strong>${ssrInterpolate(item.slug)}</strong>)</p><p>${ssrInterpolate(item.comment || "Пояснение не указано")}</p></li>`);
    });
    _push(`<!--]--></ul><div class="row"><div class="col-md-12 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">`);
    _push(ssrRenderComponent(_component_Popper, null, {
      content: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`<div${_scopeId}>Измените только текст команды,<br${_scopeId}> если хотите чтоб скрипт вызывался по кнопке из меню. <br${_scopeId}> Или оставьте как есть. <br${_scopeId}> Текст скрипта нужно также указать в качестве пункта меню.</div>`);
        } else {
          return [
            createVNode("div", null, [
              createTextVNode("Измените только текст команды,"),
              createVNode("br"),
              createTextVNode(" если хотите чтоб скрипт вызывался по кнопке из меню. "),
              createVNode("br"),
              createTextVNode(" Или оставьте как есть. "),
              createVNode("br"),
              createTextVNode(" Текст скрипта нужно также указать в качестве пункта меню.")
            ])
          ];
        }
      }),
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
        } else {
          return [
            createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(` Команда <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Команда" aria-label="Команда"${ssrRenderAttr("value", $data.slugForm.command)} maxlength="255" aria-describedby="bot-domain" required></div></div></div><button class="btn btn-outline-success mt-2 mb-2 w-100">Добавить скрипт в бота</button></div></form>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
  if ($props.slugs.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($props.slugs, (slug, index) => {
      _push(`<div class="col-12 mb-3"><div class="card"><div class="card-body"><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success mr-2"> Дублировать </button><button type="button" class="btn btn-outline-danger"> Удалить </button></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Команда</label><input type="text" class="form-control" placeholder="Команда" aria-label="Команда"${ssrRenderAttr("value", $props.slugs[index].command)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-domain">Мнемоническое имя</label><input type="text" class="form-control"${ssrIncludeBooleanAttr(true) ? " disabled" : ""} placeholder="Мнемоническое имя" aria-label="Мнемоническое имя"${ssrRenderAttr("value", $props.slugs[index].slug)} maxlength="255" aria-describedby="bot-domain" required></div></div><div class="col-12"><p>${ssrInterpolate($props.slugs[index].comment || "Пояснение не указано")}</p></div></div></div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotSlugList.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const BotSlugList = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["ssrRender", _sfc_ssrRender$1]]);
const __default__$4 = {
  props: ["botId"],
  data() {
    return {
      loading: true,
      bot_users: [],
      search: null,
      bot_users_paginate_object: null
    };
  },
  computed: {
    ...mapGetters(["getBotUsers", "getBotUsersPaginateObject"])
  },
  mounted() {
    this.loadUsers();
  },
  methods: {
    changeUserStatus(id, status) {
      this.$store.dispatch("changeUserStatus", {
        dataObject: {
          botUserId: id,
          status
        }
      }).then(() => {
        this.$notify({
          title: "Конструктор ботов",
          text: "Статус пользователя успешно изменен! Пользователь оповещен об изменении статуса!",
          type: "success"
        });
        this.loadUsers();
      }).catch(() => {
        this.$notify({
          title: "Конструктор ботов",
          text: "Ошибка изменения статуса",
          type: "error"
        });
      });
    },
    nextUsers(index) {
      this.loadUsers(index);
    },
    loadUsers(page = 0) {
      this.loading = true;
      this.$store.dispatch("loadBotUsers", {
        dataObject: {
          botId: this.botId || null,
          search: this.search
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.bot_users = this.getBotUsers;
        this.bot_users_paginate_object = this.getBotUsersPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main$6 = /* @__PURE__ */ Object.assign(__default__$4, {
  __name: "BotUserList",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="row"><div class="input-group mb-3"><input type="search" class="form-control" placeholder="Поиск пользователя" aria-label="Поиск пользователя"${ssrRenderAttr("value", _ctx.search)}><button class="btn btn-outline-secondary" type="button" id="button-addon2">Найти</button></div></div>`);
      if (_ctx.bot_users.length > 0) {
        _push(`<div class="row"><div class="col-12 mb-3"><ul class="list-group w-100"><!--[-->`);
        ssrRenderList(_ctx.bot_users, (botUser, index) => {
          _push(`<li class="list-group-item cursor-pointer"><div class="card"><div class="card-body"><p>Ф.И.О. из телеграма: ${ssrInterpolate(botUser.fio_from_telegram || "Не указано")} `);
          if (botUser.is_admin) {
            _push(`<span class="badge rounded-pill text-bg-success">Администратор</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</p><p>Имя пользователя: ${ssrInterpolate(botUser.name || "Не указано")}</p><p>Телефон: ${ssrInterpolate(botUser.phone || "Не указано")}</p><p>Почта: ${ssrInterpolate(botUser.email || "Не указано")}</p><p>id чата: ${ssrInterpolate(botUser.telegram_chat_id || "Не указано")}</p></div><div class="card-footer">`);
          if (!botUser.is_admin) {
            _push(`<button type="button" class="btn btn-outline-success"> Назначить администратором </button>`);
          } else {
            _push(`<button type="button" class="btn btn-outline-success"> Разжаловать из администраторов </button>`);
          }
          _push(`</div></div></li>`);
        });
        _push(`<!--]--></ul></div><div class="col-12">`);
        if (_ctx.bot_users_paginate_object) {
          _push(ssrRenderComponent(Pagination, {
            onPagination_page: _ctx.nextUsers,
            pagination: _ctx.bot_users_paginate_object
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<div class="row"><div class="col-12"><div class="alert alert-warning" role="alert"> У выбранного бота нет пользователей </div></div></div>`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotUserList.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __default__$3 = {
  components: {},
  props: ["companyId", "bot", "editor"],
  setup() {
  },
  data() {
    return {
      step: 0,
      templates: [],
      load: false,
      removedSlugs: [],
      removedKeyboards: [],
      descriptions: [],
      botForm: {
        bot_domain: null,
        bot_token: null,
        bot_token_dev: null,
        order_channel: null,
        main_channel: null,
        balance: null,
        tax_per_day: null,
        welcome_message: null,
        image: null,
        description: null,
        info_link: null,
        social_links: [],
        maintenance_message: null,
        level_1: 10,
        level_2: 0,
        level_3: 0,
        photos: [],
        selected_bot_template_id: null,
        slugs: [],
        keyboards: []
      }
    };
  },
  watch: {
    "botForm.selected_bot_template_id": function(oVal, nVal) {
      if (this.botForm.selected_bot_template_id != null) {
        this.loadMenusByBotTemplate(this.botForm.selected_bot_template_id);
        this.loadSlugsByBotTemplate(this.botForm.selected_bot_template_id);
      }
    }
  },
  mounted() {
    this.loadBotTemplates();
    this.loadDescription();
    if (this.bot)
      this.$nextTick(() => {
        this.loadMenusByBotTemplate(this.bot.id);
        this.loadSlugsByBotTemplate(this.bot.id);
        this.botForm = {
          id: this.bot.id || null,
          bot_domain: this.bot.bot_domain || null,
          bot_token: this.bot.bot_token || null,
          bot_token_dev: this.bot.bot_token_dev || null,
          order_channel: this.bot.order_channel || null,
          main_channel: this.bot.main_channel || null,
          balance: this.bot.balance || null,
          tax_per_day: this.bot.tax_per_day || null,
          image: this.bot.image || null,
          description: this.bot.description || null,
          info_link: this.bot.info_link || null,
          social_links: this.bot.social_links || [],
          maintenance_message: this.bot.maintenance_message || null,
          welcome_message: this.bot.welcome_message || null,
          level_1: this.bot.level_1 || 10,
          level_2: this.bot.level_2 || 0,
          level_3: this.bot.level_3 || 0,
          photos: this.bot.photos || []
        };
      });
  },
  methods: {
    addTextTo(param, text) {
      this.botForm[param] = text;
    },
    duplicateSlug(index) {
      const slug = JSON.stringify(this.botForm.slugs[index]);
      this.botForm.slugs.splice(index, 0, JSON.parse(slug));
    },
    removeKeyboard(index) {
      if (this.bot)
        this.removedKeyboards.push(index);
      this.botForm.keyboards.splice(index, 1);
    },
    addSlug(item) {
      this.botForm.slugs.push({
        id: null,
        bot_id: null,
        command: item.command,
        comment: item.comment,
        slug: item.slug
      });
      console.log("slugs after add", this.botForm.slugs);
      this.load = true;
      this.$nextTick(() => {
        this.load = false;
      });
    },
    removeSlug(index) {
      if (this.bot)
        this.removedSlugs.push(index);
      this.botForm.slugs.splice(index, 1);
    },
    loadDescription() {
      this.$store.dispatch("loadDescription").then((resp) => {
        this.descriptions = resp.data;
      });
    },
    loadMenusByBotTemplate(botId) {
      this.$store.dispatch("loadKeyboards", {
        botId
      }).then((resp) => {
        this.botForm.keyboards = resp.data;
      });
    },
    loadSlugsByBotTemplate(botId) {
      this.$store.dispatch("loadSlugs", {
        botId
      }).then((resp) => {
        this.botForm.slugs = resp.data;
      });
    },
    loadBotTemplates() {
      this.$store.dispatch("loadTemplates").then((resp) => {
        this.templates = resp.data;
      });
    },
    getPhoto(img) {
      return { imageUrl: URL.createObjectURL(img) };
    },
    onChangePhotos(e) {
      const files = e.target.files;
      this.botForm.image = null;
      for (let i = 0; i < files.length; i++)
        this.botForm.photos.push(files[i]);
    },
    addItem(name) {
      this.botForm[name].push("");
    },
    addSocialLinks() {
      this.botForm.social_links.push({
        title: null,
        url: null
      });
    },
    removeItem(name, index) {
      this.botForm[name].splice(index, 1);
    },
    removePhoto(index) {
      if (index)
        this.botForm.photos.splice(index, 1);
      else
        this.botForm.image = null;
    },
    addBot() {
      let data = new FormData();
      Object.keys(this.botForm).forEach((key) => {
        const item = this.botForm[key] || "";
        if (typeof item === "object")
          data.append(key, JSON.stringify(item));
        else
          data.append(key, item);
      });
      if (this.bot) {
        if (this.removedSlugs.length > 0)
          data.append("removed_slugs", JSON.stringify(this.removedSlugs));
        if (this.removedKeyboards.length > 0)
          data.append("removed_keyboards", JSON.stringify(this.removedKeyboards));
      }
      if (this.companyId)
        data.append("company_id", this.companyId);
      for (let i = 0; i < this.botForm.photos.length; i++)
        data.append("images[]", this.botForm.photos[i]);
      data.delete("photos");
      this.$store.dispatch(this.bot == null ? "createBot" : "updateBot", {
        botForm: data
      }).then((response) => {
        this.$emit("callback", response.data);
        this.botForm = {
          bot_domain: null,
          bot_token: null,
          bot_token_dev: null,
          order_channel: null,
          main_channel: null,
          balance: null,
          tax_per_day: null,
          image: null,
          description: null,
          info_link: null,
          social_links: [],
          maintenance_message: null,
          level_1: 10,
          level_2: 0,
          level_3: 0,
          photos: [],
          selected_bot_template_id: null,
          slugs: [],
          keyboards: []
        };
      }).catch((err) => {
      });
    }
  }
};
const _sfc_main$5 = /* @__PURE__ */ Object.assign(__default__$3, {
  __name: "Bot",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Popper = resolveComponent("Popper");
      const _directive_lazy = resolveDirective("lazy");
      _push(`<!--[-->`);
      if (__props.companyId) {
        _push(`<div class="row"><div class="col-12"><h6>Создаем бот к компании #${ssrInterpolate(__props.companyId || "Не установлен")}</h6></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.editor) {
        _push(`<div class="row mb-3 mt-3"><div class="col-12"><div class="btn-group w-100" role="group" aria-label="Basic outlined example"><button type="button" class="${ssrRenderClass([{ "btn-primary text-white": _ctx.step === 0 }, "btn btn-outline-primary"])}">Информация о боте </button><button type="button"${ssrIncludeBooleanAttr(_ctx.botForm.selected_bot_template_id === null) ? " disabled" : ""} class="${ssrRenderClass([{ "btn-primary text-white": _ctx.step === 1 }, "btn btn-outline-primary"])}">Меню бота </button><button type="button"${ssrIncludeBooleanAttr(_ctx.botForm.selected_bot_template_id === null) ? " disabled" : ""} class="${ssrRenderClass([{ "btn-primary text-white": _ctx.step === 2 }, "btn btn-outline-primary"])}">Скрипты в боте </button><button type="button"${ssrIncludeBooleanAttr(_ctx.botForm.selected_bot_template_id === null) ? " disabled" : ""} class="${ssrRenderClass([{ "btn-primary text-white": _ctx.step === 3 }, "btn btn-outline-primary"])}">Пользователи бота </button></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<form>`);
      if (_ctx.step === 0) {
        _push(`<div>`);
        if (_ctx.templates.length > 0 && __props.bot == null) {
          _push(`<div class="row"><div class="col-12"><div class="card border-success mb-3 mt-3"><div class="card-body"><label class="form-label" id="bot-level-2">`);
          _push(ssrRenderComponent(_component_Popper, null, {
            content: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div${_scopeId}>Ваш бот будет 1 в 1 как в шаблоне!<br${_scopeId}>Потом можно исправить названия кнопок в меню. </div>`);
              } else {
                return [
                  createVNode("div", null, [
                    createTextVNode("Ваш бот будет 1 в 1 как в шаблоне!"),
                    createVNode("br"),
                    createTextVNode("Потом можно исправить названия кнопок в меню. ")
                  ])
                ];
              }
            }),
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
              } else {
                return [
                  createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(` Выберите шаблон! <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><select class="form-control" aria-label="Шаблон бота" aria-describedby="bot-level-2" required><!--[-->`);
          ssrRenderList(_ctx.templates, (bot, index) => {
            _push(`<option${ssrRenderAttr("value", bot.id)}>${ssrInterpolate(bot.bot_domain)}</option>`);
          });
          _push(`<!--]--></select></div></div></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="bot-domain">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Строго взять из BotFather! ТО что при создании с окончанием на &quot;bot&quot;</div>`);
            } else {
              return [
                createVNode("div", null, 'Строго взять из BotFather! ТО что при создании с окончанием на "bot"')
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Доменное имя бота из BotFather <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Имя бота" aria-label="Имя бота"${ssrRenderAttr("value", _ctx.botForm.bot_domain)} maxlength="255" aria-describedby="bot-domain" required>`);
        if (_ctx.botForm.bot_domain) {
          _push(`<p>Проверить работу бота <a${ssrRenderAttr("href", "https://t.me/" + _ctx.botForm.bot_domain)} target="_blank">@${ssrInterpolate(_ctx.botForm.bot_domain)}</a></p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div><div class="col-12"><div class="mb-3"><div class="d-flex justify-content-between"><label class="form-label" id="bot-description">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Отобразится пользователю при первом запуске</div>`);
            } else {
              return [
                createVNode("div", null, "Отобразится пользователю при первом запуске")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Приветственное сообщение <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><div class="dropdown"><button class="btn btn-link dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-spell-check"></i></button><ul class="dropdown-menu" style="${ssrRenderStyle({ "max-height": "300px", "max-width": "300px", "overflow-y": "auto" })}"><!--[-->`);
        ssrRenderList(_ctx.descriptions, (item, index) => {
          _push(`<li><a class="dropdown-item">${ssrInterpolate(item.text)}</a></li>`);
        });
        _push(`<!--]--></ul></div></div><textarea type="text" class="form-control" placeholder="Текстовое приветствие при запуске бота" aria-label="Текстовое приветствие при запуске бота" aria-describedby="bot-description" required>${ssrInterpolate(_ctx.botForm.welcome_message)}</textarea></div></div><div class="col-12"><div class="mb-3"><div class="d-flex justify-content-between"><label class="form-label" id="bot-description">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Для меню &quot;О Боте&quot;</div>`);
            } else {
              return [
                createVNode("div", null, 'Для меню "О Боте"')
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Описание бота <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><div class="dropdown"><button class="btn btn-link dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-spell-check"></i></button><ul class="dropdown-menu" style="${ssrRenderStyle({ "max-height": "300px", "max-width": "300px", "overflow-y": "auto" })}"><!--[-->`);
        ssrRenderList(_ctx.descriptions, (item, index) => {
          _push(`<li><a class="dropdown-item">${ssrInterpolate(item.text)}</a></li>`);
        });
        _push(`<!--]--></ul></div></div><textarea type="text" class="form-control" placeholder="Текстовое описание бота" aria-label="Текстовое описание бота" aria-describedby="bot-description" required>${ssrInterpolate(_ctx.botForm.description)}</textarea></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-token">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Взять из BotFater при создании бота! Длинная нечитаемая подсвеченная строка! </div>`);
            } else {
              return [
                createVNode("div", null, "Взять из BotFater при создании бота! Длинная нечитаемая подсвеченная строка! ")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Токен бота <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Токен" aria-label="Токен"${ssrRenderAttr("value", _ctx.botForm.bot_token)} maxlength="255" aria-describedby="bot-token" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-token-dev">Токен бота (для тестирования)</label><input type="text" class="form-control" placeholder="Токен" aria-label="Токен"${ssrRenderAttr("value", _ctx.botForm.bot_token_dev)} maxlength="255" aria-describedby="bot-token-dev"></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-order-channel">Канал для заказов (id)</label><input type="text" class="form-control" placeholder="id канала" aria-label="id канала"${ssrRenderAttr("value", _ctx.botForm.order_channel)} maxlength="255" aria-describedby="bot-order-channel"></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-main-channel">Канал для постов (id,рекламный)</label><input type="text" class="form-control" placeholder="id канала" aria-label="id канала"${ssrRenderAttr("value", _ctx.botForm.main_channel)} maxlength="255" aria-describedby="bot-main-channel"></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-balance">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Начальная сумма денег на счету у конкретного бота</div>`);
            } else {
              return [
                createVNode("div", null, "Начальная сумма денег на счету у конкретного бота")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Баланс бота, руб <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="number" class="form-control" placeholder="Баланс" aria-label="Баланс"${ssrRenderAttr("value", _ctx.botForm.balance)} min="0" aria-describedby="bot-balance" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-tax-per-day">`);
        _push(ssrRenderComponent(_component_Popper, null, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>Сумма списания денег за сутки работы бота (тариф)</div>`);
            } else {
              return [
                createVNode("div", null, "Сумма списания денег за сутки работы бота (тариф)")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<i class="fa-regular fa-circle-question mr-1"${_scopeId}></i>`);
            } else {
              return [
                createVNode("i", { class: "fa-regular fa-circle-question mr-1" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(` Списание за сутки, руб <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="number" class="form-control" placeholder="Списание" aria-label="Списание"${ssrRenderAttr("value", _ctx.botForm.tax_per_day)} min="0" aria-describedby="bot-tax-per-day" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-1"> Уровень 1 CashBack, % <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", _ctx.botForm.level_1)} max="50" min="0" aria-describedby="bot-level-1" required></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-2">Уровень 2 CashBack, %</label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", _ctx.botForm.level_2)} max="50" min="0" aria-describedby="bot-level-2"></div></div><div class="col-md-6 col-12"><div class="mb-3"><label class="form-label" id="bot-level-3">Уровень 3 CashBack, %</label><input type="number" class="form-control" placeholder="%" aria-label="уровень CashBack"${ssrRenderAttr("value", _ctx.botForm.level_3)} max="50" min="0" aria-describedby="bot-level-3"></div></div><div class="col-12"><div class="mb-3"><div class="d-flex justify-content-between"><label class="form-label" id="bot-maintenance-message">Сообщение для режима тех. работ <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><div class="dropdown"><button class="btn btn-link dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-spell-check"></i></button><ul class="dropdown-menu" style="${ssrRenderStyle({ "max-height": "300px", "max-width": "300px", "overflow-y": "auto" })}"><!--[-->`);
        ssrRenderList(_ctx.descriptions, (item, index) => {
          _push(`<li><a class="dropdown-item">${ssrInterpolate(item.text)}</a></li>`);
        });
        _push(`<!--]--></ul></div></div><textarea type="text" class="form-control" placeholder="Текстовое сообщение" aria-label="Текстовое сообщение" maxlength="255" aria-describedby="bot-maintenance-message" required>${ssrInterpolate(_ctx.botForm.maintenance_message)}</textarea></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Информационная ссылка: создайте контент в <a target="_blank" href="https://telegra.ph">https://telegra.ph</a></h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><div class="row"><div class="col-12"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка ресурс telegraph" aria-label="Ссылка ресурс telegraph" maxlength="255"${ssrRenderAttr("value", _ctx.botForm.info_link)}${ssrRenderAttr("aria-describedby", "bot-info-link")}></div></div></div></div></div></div><div class="col-12"><div class="card mb-3"><div class="card-header"><h6>Ссылки на соц. сети</h6></div><div class="card-body"><div class="row"><div class="col-12"><h6>Ссылка</h6></div></div><!--[-->`);
        ssrRenderList(_ctx.botForm.social_links, (item, index) => {
          _push(`<div class="row"><div class="col-5"><div class="mb-3"><input type="text" class="form-control" placeholder="Название ссылки" aria-label="Название ссылки" maxlength="255"${ssrRenderAttr("value", _ctx.botForm.social_links[index].title)}${ssrRenderAttr("aria-describedby", "bot-social-link-" + index)} required></div></div><div class="col-5"><div class="mb-3"><input type="text" class="form-control" placeholder="Ссылка на соц.сеть" aria-label="Ссылка на соц.сеть" maxlength="255"${ssrRenderAttr("value", _ctx.botForm.social_links[index].url)}${ssrRenderAttr("aria-describedby", "bot-social-link-" + index)} required></div></div><div class="col-2"><button type="button" class="btn btn-outline-danger w-100">Удалить </button></div></div>`);
        });
        _push(`<!--]--><div class="row"><div class="col-12"><button type="button" class="btn btn-outline-success w-100">Добавить еще ссылку </button></div></div></div></div></div></div><div class="row"><div class="col-12 mb-3"><h6>Аватар для бота <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></h6><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="bot-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="bot-photos" multiple accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
        if (_ctx.botForm.photos) {
          _push(`<!--[-->`);
          ssrRenderList(_ctx.botForm.photos, (img, index) => {
            _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, _ctx.getPhoto(img).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
          });
          _push(`<!--]-->`);
        } else {
          _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, "/images-by-bot-id/" + __props.bot.id + "/" + _ctx.botForm.image))}><div class="remove"><a>Удалить</a></div></div>`);
        }
        _push(`</div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 1) {
        _push(`<div>`);
        if (_ctx.botForm.keyboards) {
          _push(ssrRenderComponent(_sfc_main$8, {
            keyboards: _ctx.botForm.keyboards,
            onRemove: _ctx.removeKeyboard
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 2) {
        _push(`<div>`);
        if (_ctx.botForm.slugs && !_ctx.load) {
          _push(ssrRenderComponent(BotSlugList, {
            slugs: _ctx.botForm.slugs,
            onAdd: _ctx.addSlug,
            onRemove: _ctx.removeSlug,
            onDuplicate: _ctx.duplicateSlug
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 3) {
        _push(`<div>`);
        if (__props.bot && !_ctx.load) {
          _push(ssrRenderComponent(_sfc_main$6, {
            "bot-id": __props.bot.id
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="row"><div class="col-12"><button type="submit" class="btn btn-outline-success w-100 p-3">`);
      if (!__props.bot) {
        _push(`<span>Добавить бота</span>`);
      } else {
        _push(`<span>Обновить бота</span>`);
      }
      _push(`</button></div></div></form><!--]-->`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Bot.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  props: ["botId"],
  data() {
    return {
      menus: [],
      deletedMenus: [],
      menuForm: {
        title: null,
        description: null,
        image: null,
        info_link: null,
        bot_id: null
      }
    };
  },
  mounted() {
    this.loadMenuByBotId();
  },
  methods: {
    loadMenuByBotId() {
      this.$store.dispatch("loadMenuByBotId", {
        botId: this.botId
      }).then((resp) => {
        this.menus = resp;
      }).catch(() => {
      });
    },
    getPhoto(imgObject) {
      return { imageUrl: URL.createObjectURL(imgObject) };
    },
    removePhoto() {
      this.menuForm.image = null;
    },
    removeItem(index) {
      if (this.menus[index].id) {
        this.deletedMenus.push(this.menus[index].id);
      }
      this.menus.splice(index, 1);
    },
    submitMenus() {
      this.menus.forEach((menu) => {
        let data = new FormData();
        Object.keys(menu).forEach((key) => {
          const item = menu[key] || "";
          if (typeof item === "object")
            data.append(key, JSON.stringify(item));
          else
            data.append(key, item);
        });
        if (this.deletedMenus.length > 0) {
          data.append("deleted_menus", JSON.stringify(this.deletedMenus));
        }
        if (typeof menu.image != "string") {
          data.append("preview", menu.image);
          data.delete("image");
        }
        this.$store.dispatch("createImageMenu", {
          menuForm: data
        }).then((response) => {
          this.$emit("callback", response.data);
          this.$notify("Меню успешно создано и сохранено");
        }).catch((err) => {
        });
      });
    },
    addImageMenu() {
      this.menuForm.bot_id = this.botId;
      this.menus.push(this.menuForm);
      this.$notify("Меню успешно добавлено в список");
      this.menuForm = {
        title: null,
        description: null,
        image: null,
        info_link: null,
        bot_id: null
      };
    },
    onChangePhotos(e) {
      const file = e.target.files[0];
      this.menuForm.image = file;
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _directive_lazy = resolveDirective("lazy");
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))}><div class="card-body"><form><h6>Графическое Меню к боту #${ssrInterpolate($props.botId || "Не установлен")}</h6><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-address"> Заголовок меню <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></label><input type="text" class="form-control" placeholder="Название меню" aria-label="Название меню" maxlength="255"${ssrRenderAttr("value", $data.menuForm.title)} aria-describedby="menu-address" required></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-description">Описание меню</label><textarea type="text" class="form-control" placeholder="Описание меню" aria-label="Описание меню" maxlength="255" aria-describedby="menu-description">${ssrInterpolate($data.menuForm.description)}</textarea></div></div></div><div class="row"><div class="col-12"><div class="mb-3"><label class="form-label" id="menu-address">Ссылка на страницу в <a target="_blank" href="https://telegra.ph">telegra.ph</a></label> с вашим меню <input type="text" class="form-control" placeholder="Информационная ссылка" aria-label="Информационная ссылка" maxlength="255"${ssrRenderAttr("value", $data.menuForm.info_link)} aria-describedby="menu-info-link"></div></div></div><div class="row"><div class="col-12 mb-3"><h5>Картинка меню с позициями <span class="badge rounded-pill text-bg-danger m-0">Нужно</span></h5><div class="photo-preview d-flex justify-content-start flex-wrap w-100"><label for="menu-photos" style="${ssrRenderStyle({ "margin-right": "10px" })}" class="photo-loader ml-2"><span>+</span><input type="file" id="menu-photos" accept="image/*" style="${ssrRenderStyle({ "display": "none" })}"></label>`);
  if ($data.menuForm.image) {
    _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}"><img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto($data.menuForm.image).imageUrl))}><div class="remove"><a>Удалить</a></div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div><div class="row"><div class="col-12"><button class="btn btn-outline-success w-100" type="submit">Добавить меню </button></div></div></form><div class="row">`);
  if ($data.menus.length > 0) {
    _push(`<!--[-->`);
    ssrRenderList($data.menus, (menu, index) => {
      _push(`<div class="col-12 mt-3"><div class="card"><div class="card-header d-flex justify-content-between"><h6>Название <strong>${ssrInterpolate(menu.title || "Не указано")}</strong></h6><a class="cursor-pointer">Удалить</a></div><div class="card-body"><p>${ssrInterpolate(menu.description || "Не указано")}</p><p> ссылка на меню из telegra.ph ${ssrInterpolate(menu.info_link || "Не указано")}</p><div class="w-100 d-flex">`);
      if (menu.image) {
        _push(`<div class="mb-2 img-preview" style="${ssrRenderStyle({ "margin-right": "10px" })}">`);
        if (typeof menu.image == "string") {
          _push(`<img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, "/images-by-bot-id/" + $props.botId + "/" + menu.image))}>`);
        } else {
          _push(`<img${ssrRenderAttrs(ssrGetDirectiveProps(_ctx, _directive_lazy, $options.getPhoto(menu.image).imageUrl))}>`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    });
    _push(`<!--]-->`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div><div class="row mt-3"><div class="col-12"><button${ssrIncludeBooleanAttr($data.menus.length === 0) ? " disabled" : ""} class="btn btn-outline-primary p-3 w-100">Сохранить меню для заведения </button></div></div></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/ImageMenu.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const ImageMenu = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender]]);
const __default__$2 = {
  data() {
    return {
      step: 0,
      load: false,
      company: null,
      location: null,
      bot: null
    };
  },
  methods: {
    reloadWebhooks() {
      axios.get("/bot/register-webhooks").then(() => {
        this.$notify({
          title: "Конструктор ботов",
          text: "Зависимости успешно обновлены!",
          type: "success"
        });
      });
    },
    reset() {
      this.step = 0;
      this.company = null;
      this.bot = null;
    },
    skip() {
      this.step++;
    },
    companyListCallback(company) {
      this.load = true;
      this.company = company;
      this.$nextTick(() => {
        this.load = false;
      });
    },
    companyCallback(company) {
      this.step++;
      this.load = true;
      this.$nextTick(() => {
        this.load = false;
      });
      document.documentElement.scrollTop = 0;
    },
    locationCallback() {
      this.step++;
      this.load = false;
      document.documentElement.scrollTop = 0;
    },
    botListCallback(bot) {
      this.load = true;
      this.bot = bot;
      this.$nextTick(() => {
        this.load = false;
      });
    },
    botCallback(bot) {
      this.step++;
      this.bot = bot;
      document.documentElement.scrollTop = 0;
    },
    imageMenuCallback(imageMenu) {
      this.step++;
      document.documentElement.scrollTop = 0;
    }
  }
};
const _sfc_main$3 = /* @__PURE__ */ Object.assign(__default__$2, {
  __name: "InitialStepper",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}>`);
      if (_ctx.step === 0) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 1: найдите или создайте компанию</h3></div>`);
        if (_ctx.step === 0) {
          _push(`<div class="card-body"><h5 class="mt-2 mb-2">Найдите существующую компанию</h5>`);
          if (!_ctx.load) {
            _push(ssrRenderComponent(_sfc_main$c, { onCallback: _ctx.companyListCallback }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`<h5 class="mb-2">или создайте новую компанию</h5>`);
          if (!_ctx.load) {
            _push(ssrRenderComponent(Company, {
              company: _ctx.company,
              onCallback: _ctx.companyCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Шаг создания компании пройден! Далее следует приступить к следующим шагам! </div></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 1) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 2: Добавьте локации заведений (не объязательно)</h3></div>`);
        if (_ctx.step === 1) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Если нет необходимости в локациях, вы можете пропустить данный шаг <button type="button" class="btn btn-primary">Пропустить </button> или же вы можете вернуться на прошлый шаг <button type="button" class="btn btn-primary">Начать заново </button></div>`);
          if (_ctx.company) {
            _push(ssrRenderComponent(Location, {
              "company-id": _ctx.company.id,
              onCallback: _ctx.locationCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 1) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 1) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Вы создалии локации в завдении! Приступаем к следующим шагам! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 2) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 3: Добавьте бота </h3></div>`);
        if (_ctx.step === 2) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> При необходимости вы можете начать по новой <button type="button" class="btn btn-primary">Начать заново </button></div><h5 class="mt-2 mb-2">Найдите существующего бота</h5>`);
          if (_ctx.company) {
            _push(ssrRenderComponent(_sfc_main$b, {
              "company-id": _ctx.company.id,
              onCallback: _ctx.botListCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`<h5 class="mb-2">или создайте нового бота</h5>`);
          if (_ctx.bot && _ctx.company && !_ctx.load) {
            _push(ssrRenderComponent(_sfc_main$5, {
              bot: _ctx.bot,
              "company-id": _ctx.company.id,
              onCallback: _ctx.botCallback
            }, null, _parent));
          } else if (_ctx.bot == null && _ctx.company && !_ctx.load) {
            _push(ssrRenderComponent(_sfc_main$5, {
              "company-id": _ctx.company.id,
              onCallback: _ctx.botCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 2) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 2) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Бот создан! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 3) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 4: Добавьте в бота меню</h3></div>`);
        if (_ctx.step === 3) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> При необходимости вы можете начать по новой <button type="button" class="btn btn-primary">Начать заново </button></div>`);
          if (_ctx.bot) {
            _push(ssrRenderComponent(ImageMenu, {
              "bot-id": _ctx.bot.id,
              onCallback: _ctx.imageMenuCallback
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step < 3) {
          _push(`<div class="card-body"><div class="alert alert-warning" role="alert"> Внимание! Вы еще не справились с прошлыми шагами! </div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.step > 3) {
          _push(`<div class="card-body"><div class="alert alert-success" role="alert"> Отлично! Все шаги выполнены <button type="button" class="btn btn-primary">Начать заново </button></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.step === 4) {
        _push(`<div class="card mb-3 p-0"><div class="card-header"><h3>Шаг 5: Обновите зависимости веб-хуков</h3></div><div class="card-body"><div class="row"><div class="alert alert-warning" role="alert"><strong>Важно!</strong> новые боты начнут работать только после того, как вы обновите зависимости! </div><div class="col-12 mb-3"><a class="btn btn-outline-success w-100">Обновить зависимости</a></div><div class="col-12"><a class="btn btn-outline-primary w-100">Начать заново</a></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/InitialStepper.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __default__$1 = {
  data() {
    return {
      load: false,
      bot: null
    };
  },
  methods: {
    botCallback(bot) {
    },
    botListCallback(bot) {
      this.load = true;
      console.log("select", bot);
      this.bot = bot;
      this.$nextTick(() => {
        this.load = false;
      });
    }
  }
};
const _sfc_main$2 = /* @__PURE__ */ Object.assign(__default__$1, {
  __name: "BotEditor",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "row" }, _attrs))}><div class="col-12">`);
      _push(ssrRenderComponent(_sfc_main$b, {
        editor: true,
        onCallback: _ctx.botListCallback
      }, null, _parent));
      _push(`</div><div class="col-12">`);
      if (_ctx.bot && !_ctx.load) {
        _push(ssrRenderComponent(_sfc_main$5, {
          bot: _ctx.bot,
          editor: true,
          onCallback: _ctx.botCallback
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/BotEditor.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Constructor_vue_vue_type_style_index_0_lang = "";
const __default__ = {
  data() {
    return {
      tab: 0
    };
  },
  computed: {
    ...mapGetters(["getErrors"])
  },
  watch: {
    getErrors: function(newVal, oldVal) {
      Object.keys(newVal).forEach((key) => {
        this.$notify({
          title: "Конструктор ботов",
          text: newVal[key],
          type: "warn"
        });
      });
    }
  },
  methods: {}
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Constructor",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row"><ul class="nav nav-tabs"><li class="nav-item"><a class="${ssrRenderClass([{ "active": _ctx.tab === 0 }, "nav-link"])}" aria-current="page" href="#">Конструктор</a></li><li class="nav-item"><a class="${ssrRenderClass([{ "active": _ctx.tab === 1 }, "nav-link"])}" href="#">Редактирование ботов</a></li></ul></div>`);
      if (_ctx.tab === 0) {
        _push(`<div class="row"><div class="col-12 pt-2 pb-2">`);
        _push(ssrRenderComponent(_sfc_main$3, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.tab === 1) {
        _push(`<div class="row"><div class="col-12 pt-2 pb-2">`);
        _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.tab === 2) {
        _push(`<div class="row"></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Constructor/Constructor.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Dashboard_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_notifications = resolveComponent("notifications");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row">`);
      _push(ssrRenderComponent(_component_notifications, { position: "top right" }, null, _parent));
      _push(`</div><div class="row"><div class="col-12 pt-3 pb-3">`);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
