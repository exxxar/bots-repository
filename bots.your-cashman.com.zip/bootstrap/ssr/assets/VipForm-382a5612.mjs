import { resolveDirective, mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrGetDirectiveProps, ssrGetDynamicModelProps, ssrIncludeBooleanAttr, ssrLooseEqual, ssrLooseContain } from "vue/server-renderer";
const __default__ = {
  data() {
    return {
      load: false,
      confirm: false,
      vipForm: {
        name: null,
        phone: null,
        email: null,
        birthday: null,
        city: null,
        country: null,
        address: null,
        sex: true
      }
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {
    submit() {
      this.loading = true;
      this.$store.dispatch("saveVip", {
        dataObject: {
          bot_id: this.bot.id,
          tg: this.tgUser,
          form: this.vipForm
        }
      }).then((resp) => {
        this.loading = false;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "VipForm",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    },
    botUser: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_mask = resolveDirective("mask");
      let _temp0;
      if (!__props.botUser.is_vip) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container pt-3 pb-3" }, _attrs))}><form class="row"><div class="col-12"><div class="input-group mb-3"><span class="input-group-text" id="vipForm-name">Ф.И.О.</span><input type="text" class="form-control" placeholder="Петров Петр Семенович" aria-label="vipForm-name"${ssrRenderAttr("value", _ctx.vipForm.name)} aria-describedby="vipForm-name" required></div><div class="input-group mb-3"><span class="input-group-text" id="vipForm-email">Почта</span><input type="email" class="form-control" placeholder="test@gmail.com"${ssrRenderAttr("value", _ctx.vipForm.email)} aria-label="vipForm-email" aria-describedby="vipForm-email" required></div><div class="input-group mb-3"><span class="input-group-text" id="vipForm-phone">Телефон</span><input${ssrRenderAttrs((_temp0 = mergeProps({
          type: "text",
          class: "form-control",
          value: _ctx.vipForm.phone,
          placeholder: "+7(000)000-00-00",
          "aria-label": "vipForm-phone",
          "aria-describedby": "vipForm-phone"
        }, ssrGetDirectiveProps(_ctx, _directive_mask, "+7(###)###-##-##")), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, _ctx.vipForm.phone))))}></div><div class="input-group mb-3"><div class="btn-group w-100" role="group" aria-label="vipForm-sex"><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.vipForm.sex, null)) ? " checked" : ""} class="btn-check" name="sex-radio-btn" id="sex-radio-btn-1" autocomplete="off" checked><label class="btn btn-outline-success" for="sex-radio-btn-1">Мужской</label><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(_ctx.vipForm.sex, null)) ? " checked" : ""} class="btn-check" name="sex-radio-btn" id="sex-radio-btn-2" autocomplete="off"><label class="btn btn-outline-success" for="sex-radio-btn-2">Женский</label></div></div><div class="input-group mb-3"><span class="input-group-text" id="basic-addon1">Дата рождения</span><input type="date" class="form-control"${ssrRenderAttr("value", _ctx.vipForm.birthday)} aria-label="vipForm-birthday" aria-describedby="vipForm-birthday"></div><div class="input-group mb-3"><span class="input-group-text" id="vipForm-city">Город</span><input type="text"${ssrRenderAttr("value", _ctx.vipForm.city)} list="datalistCityOptions" class="form-control" placeholder="Краснодар" aria-label="vipForm-city" aria-describedby="vipForm-city"><datalist id="datalistCityOptions"><option value="Краснодар"></option><option value="Ростов-на-Дону"></option><option value="Таганрог"></option><option value="Донецк"></option><option value="Москва"></option></datalist></div><div class="card w-100 mb-3 mt-3 border-success"><div class="card-body"><p>Перед отправкой данных ознакомьтесь с <a href="#">правилами данного сервиса</a> и с <a href="#">политикой конфиденциальности</a>.</p><div class="form-check form-switch"><input class="form-check-input"${ssrIncludeBooleanAttr(Array.isArray(_ctx.confirm) ? ssrLooseContain(_ctx.confirm, null) : _ctx.confirm) ? " checked" : ""} type="checkbox" role="switch" id="confirm"><label class="form-check-label" for="confirm">С правилами ознакомлен</label></div></div></div><button type="submit"${ssrIncludeBooleanAttr(!_ctx.confirm && _ctx.load) ? " disabled" : ""} class="btn btn-outline-success w-100">Отправить анкету</button></div></form></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container pt-3 pb-3" }, _attrs))}><div class="row"><div class="col-12"><div class="card border-success"><div class="card-body"> Поздравляем! Вы являетесь нашим VIP-пользователеме! Вам доступны следующие возможности: <ul><li>Накопление CashBack за покупки</li><li>Оплата товаров через CashBak</li><li>Реферальная программа</li></ul></div></div></div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/VipForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
