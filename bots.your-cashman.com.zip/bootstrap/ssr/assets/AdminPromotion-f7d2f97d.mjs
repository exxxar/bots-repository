import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs } from "vue/server-renderer";
const __default__ = {
  data() {
    return {
      loading: false
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {}
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "AdminPromotion",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    },
    botUser: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.botUser.is_admin) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row mb-2"><div class="col-12"><div class="card"><div class="card-header"><h5>Управление рассылкой и рекламой</h5></div><div class="card-body"></div></div></div></div></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row"><div class="alert alert-warning" role="alert"> Вы не являетесь администратором </div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/AdminPromotion.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
