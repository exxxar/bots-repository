import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate } from "vue/server-renderer";
const __default__ = {
  data() {
    return {
      loading: false
    };
  },
  computed: {
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  methods: {}
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "AdminStatistic",
  __ssrInlineRender: true,
  props: {
    bot: {
      type: Object
    },
    botUser: {
      type: Object
    },
    statistic: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.botUser.is_admin) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row mb-2"><div class="col-12"><div class="card"><div class="card-header"><h5>Статистика бота</h5></div><div class="card-body"><p> Всего пользователей в БД: <strong>${ssrInterpolate(__props.statistic.users_in_bd || 0)}</strong></p><p> Всего VIP: <strong>${ssrInterpolate(__props.statistic.vip_in_bd || 0)}</strong></p><p> Администраторы в БД: <strong>${ssrInterpolate(__props.statistic.admin_in_bd || 0)}</strong></p><p> Администраторы за работой: <strong>${ssrInterpolate(__props.statistic.work_admin_in_bd || 0)}</strong></p><p> Пользователей за день: <strong>${ssrInterpolate(__props.statistic.users_in_bd_today || 0)}</strong></p><p> VIP за день: <strong>${ssrInterpolate(__props.statistic.vip_in_bd_today || 0)}</strong></p><p> Выдано кэшбэка за день: <strong>${ssrInterpolate(__props.statistic.cashback_day_up || 0)} руб.</strong></p><p> Списано кэшбэка за день: <strong>${ssrInterpolate(__props.statistic.cashback_day_down || 0)} руб.</strong></p><p> Всего кэшбэка на счету у пользователей: <strong>${ssrInterpolate(__props.statistic.summary_cashback || 0)} руб.</strong></p><p> Всего кэшбэка начислено пользователям: <strong>${ssrInterpolate(__props.statistic.cashback_summary_up || 0)} руб.</strong></p><p> Всего кэшбэка списано у пользователей: <strong>${ssrInterpolate(__props.statistic.cashback_summary_down || 0)} руб.</strong></p><p> Всего за день начислено кэшбэка первого уровня: <strong>${ssrInterpolate(__props.statistic.cashback_day_up_level_1 || 0)} руб.</strong></p><p> Всего за день начислено кэшбэка второго уровня: <strong>${ssrInterpolate(__props.statistic.cashback_day_up_level_2 || 0)} руб.</strong></p><p> Всего за день начислено кэшбэка третьего уровня: <strong>${ssrInterpolate(__props.statistic.cashback_day_up_level_3 || 0)} руб.</strong></p></div></div></div></div></div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row"><div class="alert alert-warning" role="alert"> Вы не являетесь администратором </div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/AdminStatistic.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
