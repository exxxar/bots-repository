import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { U as UserInfo } from "./UserInfo-b199f12b.mjs";
import { P as Pagination } from "./Pagination-05b9527c.mjs";
import { mapGetters } from "vuex";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const __default__ = {
  data() {
    return {
      tab: 0,
      loading: false,
      section: 0,
      cashback: [],
      referrals: [],
      cashback_paginate_object: null,
      referrals_paginate_object: null,
      locationForm: {
        info: null
      },
      adminForm: {
        info: null
      },
      cashbackForm: {
        amount: null,
        info: null
      }
    };
  },
  computed: {
    ...mapGetters([
      "getCashBack",
      "getCashBackPaginateObject"
    ]),
    tg() {
      return window.Telegram.WebApp;
    },
    tgUser() {
      const urlParams = new URLSearchParams(this.tg.initData);
      return JSON.parse(urlParams.get("user"));
    }
  },
  mounted() {
    this.loadCashBack();
  },
  methods: {
    nextCashBackPage(index) {
      this.loadCashBack(index);
    },
    loadCashBack(page = 0) {
      this.$store.dispatch("loadCashBack", {
        dataObject: {
          user_id: this.botUser.user_id,
          bot_id: this.botUser.bot_id
        },
        page
      }).then((resp) => {
        this.loading = false;
        this.cashback = this.getCashBack;
        this.cashback_paginate_object = this.getCashBackPaginateObject;
      }).catch(() => {
        this.loading = false;
      });
    },
    acceptUserInLocation() {
      this.loading = true;
      this.$store.dispatch("acceptUserInLocation", {
        dataObject: {
          user_telegram_chat_id: this.botUser.telegram_chat_id,
          bot_id: this.botUser.bot_id,
          info: this.locationForm.info,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        this.locationForm.info = null;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    removeCashBack() {
      this.loading = true;
      this.$store.dispatch("removeCashBack", {
        dataObject: {
          user_telegram_chat_id: this.botUser.telegram_chat_id,
          bot_id: this.botUser.bot_id,
          cashback: this.cashbackForm.amount,
          info: this.cashbackForm.info,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        this.cashbackForm.amount = 0;
        this.cashbackForm.info = null;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    addCashBack() {
      this.loading = true;
      this.$store.dispatch("addCashBack", {
        dataObject: {
          user_telegram_chat_id: this.botUser.telegram_chat_id,
          bot_id: this.botUser.bot_id,
          cashback: this.cashbackForm.amount,
          info: this.cashbackForm.info,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        this.cashbackForm.amount = 0;
        this.cashbackForm.info = null;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    addAdmin() {
      this.loading = true;
      this.$store.dispatch("addAdmin", {
        dataObject: {
          user_telegram_chat_id: this.botUser.telegram_chat_id,
          bot_id: this.botUser.bot_id,
          info: this.adminForm.info,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        this.adminForm.info = null;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    removeAdmin() {
      this.loading = true;
      this.$store.dispatch("removeAdmin", {
        dataObject: {
          user_telegram_chat_id: this.botUser.telegram_chat_id,
          bot_id: this.botUser.bot_id,
          info: this.adminForm.info,
          tg: this.tgUser
        }
      }).then((resp) => {
        this.loading = false;
        this.adminForm.info = null;
        window.location.reload();
      }).catch(() => {
        this.loading = false;
      });
    },
    scanQR() {
      this.tg.showScanQrPopup({
        text: "test"
      }, (data) => {
        document.write("<br>" + data);
        this.tg.closeScanQrPopup();
        return true;
      });
    },
    openLink(section) {
      this.section = section;
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "AdminMain",
  __ssrInlineRender: true,
  props: {
    user: {
      type: Object
    },
    botUser: {
      type: Object
    },
    cashBack: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.user && __props.botUser) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row mb-2"><div class="col-12 d-flex justify-content-center mb-2"><div class="btn-group w-100" role="group" aria-label="Basic outlined example"><button type="button" class="${ssrRenderClass([{ "active": _ctx.tab === 0 }, "btn btn-outline-primary"])}">Инфо </button><button type="button" class="${ssrRenderClass([{ "active": _ctx.tab === 1 }, "btn btn-outline-primary"])}"> CashBack </button></div></div></div>`);
        if (_ctx.tab === 0) {
          _push(`<div class="row mb-2"><div class="col-12">`);
          _push(ssrRenderComponent(UserInfo, { "bot-user": __props.botUser }, null, _parent));
          _push(`</div></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.tab === 1) {
          _push(`<div class="row mb-2"><div class="col-12"><div class="card"><div class="card-body">`);
          if (_ctx.cashback.length > 0) {
            _push(`<ul class="list-group w-100"><!--[-->`);
            ssrRenderList(_ctx.cashback, (item, index) => {
              _push(`<li class="list-group-item"><span>${ssrInterpolate(item.money_in_check || 0)} руб.</span>, <span>${ssrInterpolate(item.description || "Не указано")}</span>, <span>${ssrInterpolate(item.operation_type ? "Начисление" : "Списание")}</span></li>`);
            });
            _push(`<!--]--></ul>`);
          } else {
            _push(`<p>У пользователя еще нет операций с CashBack-ом</p>`);
          }
          if (_ctx.cashback_paginate_object) {
            _push(ssrRenderComponent(Pagination, {
              class: "mt-2",
              onPagination_page: _ctx.nextCashBackPage,
              pagination: _ctx.cashback_paginate_object
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="row"><div class="col-12"><a class="${ssrRenderClass([{ "btn-primary text-white": _ctx.section === 5 }, "btn btn-outline-primary w-100 mb-2"])}">Отметить пользователя в заведении</a><a class="${ssrRenderClass([{ "btn-primary text-white": _ctx.section === 1 }, "btn btn-outline-primary w-100 mb-2"])}">Списать CashBack</a><a class="${ssrRenderClass([{ "btn-primary text-white": _ctx.section === 2 }, "btn btn-outline-primary w-100 mb-2"])}">Начислить CashBack</a><a class="${ssrRenderClass([{ "btn-primary text-white": _ctx.section === 3 }, "btn btn-outline-primary w-100 mb-2"])}">Добавить администратора</a><a class="${ssrRenderClass([{ "btn-primary text-white": _ctx.section === 4 }, "btn btn-outline-primary w-100 mb-2"])}">Убрать администратора</a></div></div>`);
        if (_ctx.section === 2) {
          _push(`<div class="row"><form><p>У пользователя <strong>${ssrInterpolate(__props.cashBack.amount || 0)} руб</strong> CashBack</p><div class="mb-3"><label for="bill-amount" class="form-label">Сумма в чеке, руб</label><input type="number" min="0" class="form-control" id="bill-amount"${ssrRenderAttr("value", _ctx.cashbackForm.amount)} placeholder="Сумма" required></div><div class="mb-3"><label for="bill-info" class="form-label">Информация о чеке, номер</label><textarea class="form-control" placeholder="Информация" id="bill-info" rows="3" required>${ssrInterpolate(_ctx.cashbackForm.info)}</textarea></div><div class="mb-3"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} type="submit" class="btn btn-outline-success w-100">Отправить </button></div></form></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.section === 1) {
          _push(`<div class="row"><form><p>У пользователя <strong>${ssrInterpolate(__props.cashBack.amount || 0)} руб</strong> CashBack</p><div class="mb-3"><label for="bill-amount" class="form-label">Сумма списания CashBack, руб</label><input type="number" min="0" class="form-control" id="bill-amount"${ssrRenderAttr("value", _ctx.cashbackForm.amount)} placeholder="Сумма" required></div><div class="mb-3"><label for="bill-info" class="form-label">Причина списания</label><textarea class="form-control" placeholder="Информация" id="bill-info" rows="3" required>${ssrInterpolate(_ctx.cashbackForm.info)}</textarea></div><div class="mb-3"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} type="submit" class="btn btn-outline-success w-100">Отправить </button></div></form></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.section === 3) {
          _push(`<div class="row"><form><div class="mb-3"><label for="bill-info" class="form-label">Причина добавления администратора</label><textarea class="form-control" placeholder="Информация" id="bill-info" rows="3" required>${ssrInterpolate(_ctx.adminForm.info)}</textarea></div><div class="mb-3"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} type="submit" class="btn btn-outline-success w-100">Подтвредить </button></div></form></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.section === 4) {
          _push(`<div class="row"><form><div class="mb-3"><label for="bill-info" class="form-label">Причина разжалования администратора</label><textarea class="form-control" placeholder="Информация" id="bill-info" rows="3" required>${ssrInterpolate(_ctx.adminForm.info)}</textarea></div><div class="mb-3"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} type="submit" class="btn btn-outline-success w-100">Подтвредить </button></div></form></div>`);
        } else {
          _push(`<!---->`);
        }
        if (_ctx.section === 5) {
          _push(`<div class="row"><form><div class="mb-3"><label for="bill-info" class="form-label">Комменатрий</label><textarea class="form-control" placeholder="Информация" id="bill-info" rows="3" required>${ssrInterpolate(_ctx.locationForm.info)}</textarea></div><div class="mb-3"><button${ssrIncludeBooleanAttr(_ctx.loading) ? " disabled" : ""} type="submit" class="btn btn-outline-success w-100">Отметить </button></div></form></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}><div class="row"><div class="alert alert-warning" role="alert"> Не найден пользователь! </div></div></div>`);
      }
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/AdminMain.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
