import { mergeProps, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  props: ["botUser"]
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))}><div class="card-header"><h4>Информация о пользователе</h4></div><div class="card-body"><p>Имя из телеграмма <strong>${ssrInterpolate($props.botUser.fio_from_telegram || "Не указано")}</strong></p><p>Возраст <strong>${ssrInterpolate($props.botUser.age || "Не указано")}</strong></p><p>День рождения <strong>${ssrInterpolate($props.botUser.birthday || "Не указано")}</strong></p><p>Пол <strong>${ssrInterpolate($props.botUser.sex ? "Мужчина" : "Женщина")}</strong></p><p>Страна <strong>${ssrInterpolate($props.botUser.country || "Не указано")}</strong></p><p>Город <strong>${ssrInterpolate($props.botUser.city || "Не указано")}</strong></p><p>Адрес <strong>${ssrInterpolate($props.botUser.address || "Не указано")}</strong></p><p>Явяется VIP <strong>${ssrInterpolate($props.botUser.is_vip ? "Да" : "Нет")}</strong></p><p>Явяется администратором данного бота <strong>${ssrInterpolate($props.botUser.is_admin ? "Да" : "Нет")}</strong></p>`);
  if ($props.botUser.is_admin) {
    _push(`<p>Работает в данный момент <strong>${ssrInterpolate($props.botUser.is_work ? "Да" : "Нет")}</strong></p>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<p>Пользователь в заведении <strong>${ssrInterpolate($props.botUser.user_in_location ? "Да" : "Нет")}</strong></p></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/UserInfo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const UserInfo = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  UserInfo as U
};
