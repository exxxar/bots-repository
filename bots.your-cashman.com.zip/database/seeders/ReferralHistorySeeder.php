<?php

namespace Database\Seeders;

use App\Models\ReferralHistory;
use Illuminate\Database\Seeder;

class ReferralHistorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       // ReferralHistory::factory()->count(5)->create();
    }
}
