<?php

namespace Database\Seeders;

use App\Models\NotificationSchedule;
use Illuminate\Database\Seeder;

class NotificationScheduleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //NotificationSchedule::factory()->count(5)->create();
    }
}
