<script setup>
import ProductList from "@/Components/Products/ProductList.vue";

</script>
<template>

    <div class="container pt-3 pb-3">
        <ProductList/>
    </div>
</template>
